children = script.parent:GetChildren()
debugText = script:GetCustomProperty("DebugText"):WaitForObject()

_G["cerberus.games.PlayerLocation"] = script.context



triggersToRooms = {}

for _, room in pairs(children) do
    roomChildren = room:GetChildren()
    for _, trigger in pairs(roomChildren) do
        if trigger:IsA("Trigger") then
            triggersToRooms[trigger] = room.name
        end
    end
end


player = Game.GetLocalPlayer()


currentRoomName = nil

function Tick()

    newRoom = nil

    for trigger, roomName in pairs(triggersToRooms) do
        if trigger:IsOverlapping(player) then
            newRoom = roomName
        end
    end

    if newRoom then
        currentRoomName = newRoom
    end

   if currentRoomName then
        debugText.text = currentRoomName
   end

   Task.Wait()
   Task.Wait()
   Task.Wait() 
end

function GetCurrentRoomName()
    return currentRoomName
end