local API = require(script:GetCustomProperty("API"))

local OUIJI_BOARD = script:GetCustomProperty("OuijaBoard"):WaitForObject()
local INTERACTIVE_POINT = script:GetCustomProperty("InteractivePoint"):WaitForObject()

function OnPointInteraction(interactivePoint)
    if INTERACTIVE_POINT == interactivePoint then
        PlayScene()
    end
end

local HINTS = {
    State1 = { -- We are outside the house
        text = "HELLO",
        dialog = "You are not supposed to be here.."
    },
    State2 = {-- We are in the dining room first time
        text = "DRAWER",
        dialog = "Drawer.."
    },
    State3 = {-- We have the first note
        text = "BATHROOM",
        dialog = "Bathroom.."
    },
    State4 = {-- We have left the bathroom, time to go upstairs to the girls room
        text = "UP",
        dialog = "Up?"
    },
    State5 = {-- We have gone into the girls room, time to go into the boys bedroom
        text = "LETTER",
        dialog = ""
    },
    State6 = {-- We have found the note! We have to go to the pantry and find the code
        text = "PANTRY",
        dialog = "Pantry.."
    },
    State7 = {-- We have found the code. Time to go to the master bedroom
        text = "MASTER",
        dialog = "Master.. the master bedroom?"
    },
    State8 = {-- We are back down again with the key
        text = "STUDY",
        dialog = "The study room.. I have the key for that.."
    },
    State9 = {-- This is not reachable
        text = "BASEMENT",
        dialog = "I shouldnt be able to read this.."
    },
    State10 = {-- This is not reachable
        text = "BYE",
        dialog = "This should not be reachable"
    },
    State11 = {-- This is not reachable
        text = "BYE",
        dialog = "This should not be reachable"
    },
    State12 = {-- This is not reachable
        text = "BYE",
        dialog = "This should not be reachable"
    },

    -- Return back the state
    GetHint = function(self, n)
        return self["State"..tostring(n)].text, self["State"..tostring(n)].dialog
    end
}

function PlayScene()

    INTERACTIVE_POINT.context.isEnabled = false

    -- BOOOM! 1 line :)
    local text, dialog = HINTS:GetHint(API.SceneStateManager.GetSceneState())

    OUIJI_BOARD.context.ReadBoard(text)

    Task.Wait(0.5)
    
    API.Dialog.Play(dialog, 1)

    Task.Wait(10)

    INTERACTIVE_POINT.context.isEnabled = true
end


Events.Connect("OnPointInteraction", OnPointInteraction)







