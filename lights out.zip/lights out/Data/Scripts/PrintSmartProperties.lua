properties = script.parent:GetSmartProperties()


for key, value in pairs(properties) do
    print (key)
end




function Tick()

    test = CoreMath.Lerp((math.sin(time() * 4 ) + 1) * 0.5, 1.3, 5)
    script.parent:SetSmartProperty("Center Area Contrast", test)

end