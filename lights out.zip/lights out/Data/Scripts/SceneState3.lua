--[[
    SCENE STATE 3 INITIALIZATION
]]--

local API = require(script:GetCustomProperty("API"))

local BATHTUB_LIGHT = script:GetCustomProperty("BathtubLight"):WaitForObject()

function EnterState()
    print ("We are entering scene state 3")

    -- Initialize with all lights off
    API.SkyLightDriver.Inside()
    API.LightDriver.Off("All")

    -- forgot to lock all the doors except bathroom, but meh
    API.DoorDriver.Open("Bathroom", 1)
    API.DoorDriver.Open("Kitchen", 1)

    API.LightDriver.On("Bathroom")
    API.LightDriver.On("Kitchen")
    API.LightDriver.On("Dining")
    API.LightDriver.On("MoonLights")
    API.LightDriver.On("EntranceHall")
    API.LightDriver.Off(BATHTUB_LIGHT)
end

return EnterState
