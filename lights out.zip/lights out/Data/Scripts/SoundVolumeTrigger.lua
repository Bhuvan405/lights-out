
local API = require(script:GetCustomProperty("API"))
local TRIGGER = script.parent
local AUDIO = script:GetCustomProperty("Audio"):WaitForObject()
local ORIGINAL_VOLUME = AUDIO.volume
local PLAYER = Game.GetLocalPlayer()
local FADE_DURATION = 1
local fadeInAmount = 1
local isFadingIn = false

function Tick(dt)
    if API.SceneStateManager.GetSceneState() < 3 then
        return
    end

    if (TRIGGER:IsOverlapping(PLAYER)) then
        fadeInAmount = fadeInAmount + dt / FADE_DURATION
        if fadeInAmount > 1 then
            fadeInAmount = 1
        end
    else
        fadeInAmount = fadeInAmount - dt / FADE_DURATION
        if fadeInAmount < 0 then
            fadeInAmount = 0
        end
    end

    if fadeInAmount > 0.5 then
        if not isFadingIn then
            isFadingIn = true
            AUDIO:FadeIn(1)
        end

    else
        if isFadingIn then
            isFadingIn = false
            AUDIO:FadeOut(1)
        end
    end
end




