local API = require(script:GetCustomProperty("API"))
local ROOT = script:GetCustomProperty("Root"):WaitForObject()

local TRIGGER = ROOT:GetCustomProperty("Trigger"):WaitForObject()
local INSPECT_OBJECT = ROOT:GetCustomProperty("InspectObject"):WaitForObject()
local OFFSET = ROOT:GetCustomProperty("Offset")
local INTERACTIVE_POINT = ROOT:GetCustomProperty("InteractivePoint"):WaitForObject()

local restPosition = INSPECT_OBJECT:GetWorldPosition()
local restRotation = INSPECT_OBJECT:GetWorldRotation()
local restParent = INSPECT_OBJECT.parent

local player = Game.GetLocalPlayer()

local leftMouseDown = false

local isInspecting = false
 
local lastCursorPosition = nil

local localRotation = Quaternion.IDENTITY

local interpolationAmount = 0
local interpolationSpeed = 0

local inputPressedBinding = nil
local inputReleasedBinding = nil

function OnInputPressed(player, input)
    if input == "ability_primary" then
        leftMouseDown = true
    end

    if input == "ability_secondary" then
        PutItemBack()
    end
end
-- I only just tuned in o_o dealing with kid stuff..... tsk tsk tsk.. mom was very mad apologies for my tardiness
function OnInputReleased(player, input)
    if interpolationAmount == 1 then
        if input == "ability_primary" then
            leftMouseDown = false
            PutItemBack()
        end
    end
end


 function SmoothStep(x)
    return x * x * (3 - 2 * x)
 end

 function Tick(dt)
    interpolationAmount = CoreMath.Clamp(interpolationAmount + interpolationSpeed*dt, 0, 1)

    if isInspecting then
        print ("I am inspecting " , interpolationAmount, interpolationSpeed, dt)
        local viewWorldRotation = player:GetViewWorldRotation()

        position = UI.GetCursorPosition() / UI.GetScreenSize() - Vector2.ONE * 0.5
    
        if leftMouseDown then
            delta = position - lastCursorPosition
            delta = delta * -360
            spinHorizontal = Quaternion.New(viewWorldRotation * Vector3.UP, delta.x)
            spinVertical = Quaternion.New(viewWorldRotation * Vector3.RIGHT, delta.y)
            
            localRotation = spinHorizontal * spinVertical * localRotation
        end

        lastCursorPosition = position

        worldPosition = player:GetViewWorldPosition() + viewWorldRotation * OFFSET

        r = SmoothStep(interpolationAmount)
        INSPECT_OBJECT:SetWorldPosition(Vector3.Lerp(restPosition, worldPosition, r))
        INSPECT_OBJECT:SetWorldRotation(Rotation.New( Quaternion.Slerp( Quaternion.New(restRotation), localRotation * Quaternion.New(viewWorldRotation), r)))

    end
 end



function PickupItem()
    if interpolationAmount == 0 then
        print ("Picking up the fear trophy")
        restPosition = INSPECT_OBJECT:GetWorldPosition()
        restRotation = INSPECT_OBJECT:GetWorldRotation()
        restParent = INSPECT_OBJECT.parent

        INTERACTIVE_POINT.context.isEnabled = false

    -- Begin interaction
        isInspecting = true
        INSPECT_OBJECT.parent = World.GetRootObject()

        API.GameManager.DisableLook()
        API.GameManager.DisableMovement()

        interpolationSpeed = 1

        API.CursorDriver.ShowCursor()

        inputPressedBinding = player.bindingPressedEvent:Connect(OnInputPressed)
        inputReleasedBinding = player.bindingReleasedEvent:Connect(OnInputReleased)

    end
end

function PutItemBack()
    if interpolationAmount == 1 then
        API.GameManager.EnableMovement()
        API.GameManager.EnableLook()

        inputPressedBinding:Disconnect()
        inputReleasedBinding:Disconnect()
        inputPressedBinding = nil
        inputReleasedBinding = nil

        interpolationSpeed = -1

        API.CursorDriver.HideCursor()

        Task.Wait(1)

        isInspecting = false
        INTERACTIVE_POINT.context.isEnabled = true


        INSPECT_OBJECT.parent = restParent
        INSPECT_OBJECT:SetWorldPosition(restPosition)
        INSPECT_OBJECT:SetWorldRotation(restRotation)

        Events.Broadcast("InspectedItemPutBack", script)
    end
end

function OnPointInteraction(interactivePoint)
    if INTERACTIVE_POINT == interactivePoint then
        PickupItem()
    end
end

 Events.Connect("OnPointInteraction", OnPointInteraction)