local API = require(script:GetCustomProperty("API"))
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        PlayScene()
    end
end

function PlayScene()
    API.DoorDriver.Lock("Entrance")
    Task.Wait(0.5)
    API.GameManager.DisableMovement()
    API.Dialog.Play("Huh?..", 1)
    Task.Wait(0.5)
    API.Dialog.Play("It must of been the wind..", 1)
    API.LightDriver.FlickerOff("All")
    API.SkyLightDriver.Inside()
    API.LightDriver.FlickerOn("EntranceHall")
    Task.Wait(0.5)
    API.Dialog.Play("Hello?!? .. Anybody home?", 1)
    Task.Wait(0.5)
    API.Dialog.Play("Mr Finch.. ?", 1)
    API.LightDriver.FlickerOn("Dining")
    Task.Wait(0.5)
    API.Dialog.Play("Probably should check the dining room first..", 1)
    API.GameManager.EnableMovement()
    API.SceneStateManager.NextScene()
end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)