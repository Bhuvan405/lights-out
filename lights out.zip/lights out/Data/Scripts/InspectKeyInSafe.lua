local API = require(script:GetCustomProperty("API"))

local INTERACTIVE_POINT = script:GetCustomProperty("InteractivePoint"):WaitForObject()

local INSPECT_OBJECT = script:GetCustomProperty("InspectObject"):WaitForObject()
local OFFSET = script:GetCustomProperty("Offset")
local DURATION = script:GetCustomProperty("Duration")

local restPosition = INSPECT_OBJECT:GetWorldPosition()
local restRotation = INSPECT_OBJECT:GetWorldRotation()

local player = Game.GetLocalPlayer()


function SmoothStep(x)
    return x * x * (3 - 2 * x)
 end

function OnPointInteraction(interactivePoint)
    if INTERACTIVE_POINT == interactivePoint then
        PlayScene()
    end
end

function ChangeParentMaintainPositionRotation(coreObject, newParent)
    if Object.IsValid(coreObject) then
        local originalWorldPosition = coreObject:GetWorldPosition()
        local originalWorldRotation = coreObject:GetWorldRotation()

        INSPECT_OBJECT.parent = newParent

        coreObject:SetWorldPosition(originalWorldPosition)
        coreObject:SetWorldRotation(originalWorldRotation)
    else
        warn("ChangeParentMaintainPositionRotation core object is nil, cant change parent")
    end
end

function AttachToLocalViewMaintainWorldPositionRotation(coreObject)
    if Object.IsValid(coreObject) then
        local originalWorldPosition = coreObject:GetWorldPosition()
        local originalWorldRotation = coreObject:GetWorldRotation()

        coreObject:AttachToLocalView()

        coreObject:SetWorldPosition(originalWorldPosition)
        coreObject:SetWorldRotation(originalWorldRotation)
    else
        warn("ChangeParentMaintainPositionRotation core object is nil, cant change parent")
    end
end

function PlayScene()
    local startTime = time()

    INTERACTIVE_POINT.context.isEnabled = false

    local originalParent = INSPECT_OBJECT.parent

    ChangeParentMaintainPositionRotation(INSPECT_OBJECT, nil)

    local duration = DURATION

    repeat
        local t = math.abs(time() - startTime) / duration
        if t > 1 then
            t = 1
        end
        UpdatePositionAndRotation(t)

        Task.Wait()
    until t == 1

    -------
    ChangeParentMaintainPositionRotation(INSPECT_OBJECT, originalParent)

    restPosition = Game.GetLocalPlayer():GetWorldPosition()

    -- Put the key inside you
    duration = DURATION
    startTime = time()
    repeat
        local t = math.abs(time() - startTime) / duration
        if t > 1 then
            t = 1
        end
        UpdatePositionAndRotation(1-t)

        Task.Wait()
    until t == 1

    -- Re-enable interactive point after a delay so the player can read it again if they want
    Task.Wait(1)

    INSPECT_OBJECT.isEnabled = false

    Task.Wait(0.5)

    API.Dialog.Play("This key could be useful later..", 1)
    API.SceneStateManager.NextScene()
end

function UpdatePositionAndRotation(r)

    local viewWorldRotation = player:GetViewWorldRotation()

    local worldPosition = player:GetViewWorldPosition() + viewWorldRotation * OFFSET

    r = SmoothStep(r)

    INSPECT_OBJECT:SetWorldPosition(Vector3.Lerp(restPosition, worldPosition, r))

    if Object.IsValid(INSPECT_OBJECT) then
        INSPECT_OBJECT:SetWorldRotation(Rotation.New( Quaternion.Slerp( Quaternion.New(restRotation), Quaternion.New(viewWorldRotation), r)))
    end

end

Events.Connect("OnPointInteraction", OnPointInteraction)