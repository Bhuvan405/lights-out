--[[
    SCENE STATE 2 INITIALIZATION
]]--

local API = require(script:GetCustomProperty("API"))

function EnterState()
    API.SkyLightDriver.Inside()
    API.LightDriver.Off("All")
    API.LightDriver.FlickerOn("Dining")
    API.DoorDriver.Lock("All")
end


return EnterState
