local propBook = script:GetCustomProperty("Book"):WaitForObject()

function Tick()
    propBook:SetVelocity( propBook:GetVelocity() * 0.9)
end