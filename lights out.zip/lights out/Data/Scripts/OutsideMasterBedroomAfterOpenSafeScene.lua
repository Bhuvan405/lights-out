local API = require(script:GetCustomProperty("API"))

local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()
local THROW_ROTATION = script:GetCustomProperty("ThrowRotation"):WaitForObject()
local THROW_SPEED = script:GetCustomProperty("ThrowSpeed")
local DEMON_ATTACH_TO_CAMERA = script:GetCustomProperty("DemonAttachToCamera"):WaitForObject()
local SOUND = script:GetCustomProperty("Sound"):WaitForObject()

local LOCAL_PLAYER = Game.GetLocalPlayer()

DEMON_ATTACH_TO_CAMERA.isEnabled = false

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        PlayScene()
    end
end

function PlayScene()
    API.GameManager.DisableMovement()

    API.Torch.Off()
    API.SkyLightDriver.Dark()

    Task.Wait(0.3)
    Task.Wait(math.random())

    API.Torch.On()
    SOUND:Play()
    DEMON_ATTACH_TO_CAMERA.isEnabled = true
    DEMON_ATTACH_TO_CAMERA:AttachToLocalView()
    Task.Wait(0.3)
    DEMON_ATTACH_TO_CAMERA.isEnabled = false
   
    API.GameManager.EnableMovement()
    API.Torch.On()

    SOUND:FadeOut(1.5)

    API.HeartBeatDriver.SetHeartRate(API.HeartBeatDriver.SCARED_BPM)
    
    Events.BroadcastToServer("ManagePlayer", "throw", THROW_ROTATION:GetWorldRotation() * Vector3.FORWARD * THROW_SPEED * LOCAL_PLAYER.mass)
    API.Dialog.Play("Whaaat the?!?!", 1)

    Task.Wait(5)

    API.HeartBeatDriver.SetHeartRate(API.HeartBeatDriver.RELAXED_BPM)
end


TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)