local TORCH = script:GetCustomProperty("Torch"):WaitForObject()
local CAMERA = script:GetCustomProperty("Camera"):WaitForObject()

local LOCAL_PLAYER = Game.GetLocalPlayer()

function OnPlayerJoined(player)
    if player == LOCAL_PLAYER then
        LOCAL_PLAYER:SetDefaultCamera(CAMERA)
        Task.Wait(1)
        TORCH:AttachToLocalView()
        TORCH:SetPosition(CAMERA:GetWorldPosition() + Vector3.FORWARD * 45)
    end
end

Game.playerJoinedEvent:Connect(OnPlayerJoined)