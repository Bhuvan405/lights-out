local API = require(script:GetCustomProperty("API"))
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()

local DUDE_IN_WINDOW_ART = script:GetCustomProperty("DudeInWindowArt"):WaitForObject()

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        PlayScene()
    end
end

function PlayScene()
    API.WaitUntilOnScreen(DUDE_IN_WINDOW_ART:GetWorldPosition())
    DUDE_IN_WINDOW_ART.isEnabled = false
end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)