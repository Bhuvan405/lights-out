local API = require(script:GetCustomProperty("API"))

local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()
local AREA_LIGHT = script:GetCustomProperty("AreaLight"):WaitForObject()
local SHOWER_GIRL = script:GetCustomProperty("Showergirl"):WaitForObject()
local INTERACTIVE_POINT = script:GetCustomProperty("InteractivePoint"):WaitForObject()
local SHOWER_CURTAIN_TRIGGER = script:GetCustomProperty("ShowCurtainTrigger"):WaitForObject()
local SHOWER_CURTAIN_SCALE_GROUNDA = script:GetCustomProperty("ShowerCurtainScaleGroundA"):WaitForObject()
local SHOWER_CURTAIN_SCALE_GROUNDB = script:GetCustomProperty("ShowerCurtainScaleGroundB"):WaitForObject()
local LOOK_AT_DOOR_POSITION = script:GetCustomProperty("LookAtDoor"):WaitForObject()

SHOWER_GIRL.isEnabled = false

SHOWER_CURTAIN_TRIGGER.isEnabled = false

function ScaleShowerCurtain(scaleGroup)
    startTime = time()

    while true do
        localTime = CoreMath.Clamp(time() - startTime, 0, 1)
        scaleGroup.SetScale(Vector3.New(1, 1-localTime * 0.7, 1))
        if localTime > 1 then
            break
        end
        Task.Wait()
    end
end

function OnPointInteraction(interactivePoint)
    if INTERACTIVE_POINT == interactivePoint then
        -- Pull the shower curtains back!
        SHOWER_CURTAIN_TRIGGER.isEnabled = false
        Task.Spawn(function () ScaleShowerCurtain(SHOWER_CURTAIN_SCALE_GROUNDA.context) end )
        Task.Spawn(function () ScaleShowerCurtain(SHOWER_CURTAIN_SCALE_GROUNDB.context) end )
        SHOWER_GIRL.isEnabled = false
        API.HeartBeatDriver.SetHeartRate(API.HeartBeatDriver.RELAXED_BPM)

        Task.Wait(0.2)
        API.LightDriver.FlickerOn("Bathroom")
        API.LightDriver.Off(AREA_LIGHT)
        API.GameManager.DisableMovement()
        Task.Wait(1)
        API.GameManager.EnableMovement()
        API.Torch.Off()
        API.DoorDriver.Lock("Bathroom")
        Task.Wait(0.2)
        API.DoorDriver.Unlock("Bathroom")
        Task.Wait(0.2)
        API.DoorDriver.Open("Bathroom", 1)
        API.SceneStateManager.NextScene()
    end
end

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        Sequence()
    end
end


function Sequence()
    TRIGGER.isEnabled = false
    API.DoorDriver.Close("Bathroom", 0.5)
    API.SkyLightDriver.Dark()
    Task.Wait(0.5)
    API.LightDriver.FlickerOff("Bathroom")
    Task.Wait(0.2)
    API.Torch.On()
    Task.Wait(1)
    API.LightDriver.FlickerForever(AREA_LIGHT)
    API.Torch.Off()
    SHOWER_GIRL.isEnabled = true
    SHOWER_CURTAIN_TRIGGER.isEnabled = true
    Events.Connect("OnPointInteraction", OnPointInteraction)

    API.HeartBeatDriver.SetHeartRate(API.HeartBeatDriver.ANXIOUS_BPM)
end


TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)