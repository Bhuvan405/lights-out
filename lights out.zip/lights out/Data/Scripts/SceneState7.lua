--[[
    SCENE STATE 7 INITIALIZATION
]]--

local API = require(script:GetCustomProperty("API"))

function EnterState()
    API.SkyLightDriver.Dark()
    
    -- Initialize with all lights off
    API.LightDriver.Off("All")

    API.DoorDriver.Lock("LeftStudy")
    API.DoorDriver.Lock("RightStudy")

    API.DoorDriver.Open("Parents", 1)
end


return EnterState
