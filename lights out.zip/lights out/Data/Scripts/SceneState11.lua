local MUSIC = script:GetCustomProperty("Music"):WaitForObject()


--[[
    SCENE STATE 11 INITIALIZATION
]]--


local API = require(script:GetCustomProperty("API"))

function EnterState()
    MUSIC:Play()

    API.SkyLightDriver.Outside()

    Task.Wait(2)

    API.Dialog.Play("W-what's going on?!?")

    Task.Wait(1)

    -- Make the player run twice as fast!
    API.GameManager.ChangeWalkSpeed(2)

    API.SkyLightDriver.Dark()
    API.HeartBeatDriver.SetHeartRate(API.HeartBeatDriver.SCARED_BPM)

    -- Initialize with all lights off
    API.LightDriver.Off("All")

    -- Flicker the basement?
    API.LightDriver.FlickerOff("Basement")

    Task.Wait(3)

    API.Dialog.Play("I better get out of here...")

    Task.Wait(1)

    API.SkyLightDriver.Inside()

    API.Torch.On()

    Task.Wait(1)

    API.SkyLightDriver.Outside()
end


return EnterState
