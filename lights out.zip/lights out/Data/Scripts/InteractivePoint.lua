-- Gets a module registered to the global table, waiting until its found
function GetModule(name)
    local module = _G[name]

    if module ~= nil then
        return module
    end

    startTime = time()
    repeat
        print("waiting for ..." .. name)
        Task.Wait()
        module = _G[name]
    until module ~= nil

    return module
end

-- Get the module
InteractivePoints = GetModule("cerberus.games.InteractivePoints")

-- Register this
InteractivePoints.AddPointOfInterest(script)


local label = script:GetCustomProperty("Label")
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()

local player = Game.GetLocalPlayer()

isEnabled = true -- added new one because im more likely to use this
pointInteractive = true -- make global

function GetLabel()
    return label
end

function SetLabel(newLabel)
    label = newLabel
end

function IsEnabled()
    if TRIGGER then
        return TRIGGER:IsOverlapping(player) and pointInteractive and isEnabled
    end
    return pointInteractive and isEnabled
end