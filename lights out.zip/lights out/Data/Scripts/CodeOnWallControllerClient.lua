local ROOT = script:GetCustomProperty("Root"):WaitForObject()

local FIRST_DIGIT = script.parent:GetCustomProperty("FirstDigit"):WaitForObject()
local SECOND_DIGIT = script.parent:GetCustomProperty("SecondDigit"):WaitForObject()
local THIRD_DIGIT = script.parent:GetCustomProperty("ThirdDigit"):WaitForObject()
local FORTH_DIGIT = script.parent:GetCustomProperty("ForthDigit"):WaitForObject()


function OnGeneratedPin(pin)
    FIRST_DIGIT:SetSmartProperty("Shape Index", pin.firstDigit)
    SECOND_DIGIT:SetSmartProperty("Shape Index", pin.secondDigit)
    THIRD_DIGIT:SetSmartProperty("Shape Index", pin.thirdDigit)
    FORTH_DIGIT:SetSmartProperty("Shape Index", pin.fourthDigit)
end


Events.Connect("GeneratedPin", OnGeneratedPin)