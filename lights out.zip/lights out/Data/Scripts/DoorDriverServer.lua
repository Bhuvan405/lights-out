

local ROOT = script:GetCustomProperty("Root"):WaitForObject()

-- This is just if we want to broadcast via name

--[[
(Door names)
GirlBedroomDoor
BoyBedroomDoor
MasterBedroomDoor
BasementDoor
BathroomDoor
EntranceDoor
KitchenDoor
LeftGate
RightGate
StudyDoorLeft
StudyDoorRight

--------

opendoor
closedoor
startshakedoor
stopdoorshake
lockdoor
unlockdoor
instantlyclosedoor
instantlyopendoor

 ]]

 -- Modified the door driver to automatically unlock a door when calling open as well as added close door to the lock command.



local DOORS = {}

Task.Wait()


for _, door in pairs(ROOT:GetChildren()) do
    -- this is a bit hacky :/
    local basicDoorControllerServer = door:FindChildByName("ServerContext"):FindChildByName("BasicDoorControllerServer").context
    DOORS[door.name] = basicDoorControllerServer

    print ("Registered door " .. door.name)
    print (door:FindChildByName("ServerContext"):FindChildByName("BasicDoorControllerServer").context)
end


function OpenDoor(door, duration)
    print ("OpenDoor")
    if not Object.IsValid(door) then
        print("The door is not valid")
    end
    door.UnlockDoor()
    door.OpenDoor(duration)
end

function CloseDoor(door, duration)
    door.CloseDoor(duration)
end

function SilentlyCloseDoor(door, duration)
    door.SilentlyCloseDoor(duration)
end

function SilentlyOpenDoor(door, duration)
    door.SilentlyOpenDoor(duration)
end

function ShakeDoor(door)
    door.ShakeDoor()
end

-- Makes door be un-opennable
function LockDoor(door)
    door.CloseDoor(1)
    door.LockDoor()
end

function UnlockDoor(door)
    door.UnlockDoor()
end

function InstantlyCloseDoor(door)
    door.InstantlyCloseDoor()
end

function InstantlyOpenDoor(door)
    door.InstantlyOpenDoor()
end


functionTable = {
    opendoor = OpenDoor,
    closedoor = CloseDoor,
    silentlyclosedoor = SilentlyCloseDoor,
    silentlyopendoor = SilentlyOpenDoor,
    shakedoor = ShakeDoor,
    lockdoor = LockDoor,
    unlockdoor = UnlockDoor,
    instantlyclosedoor = InstantlyCloseDoor,
    instantlyopendoor = InstantlyOpenDoor,
}

function DoorCommand(player, doorName, command, duration)
    if doorName == "All" then
        print ("Telling all doors to ", command, " with duration ", duration)
        for doorName, doorServer in pairs(DOORS) do
            local func = functionTable[command]

            if func == nil then
                error("Could not find the function, probably a typo: " .. command)
            end

            func(doorServer, duration)
        end
    else
        print("Telling door ", doorName, " to ", command, " with duration ", duration)
        door = DOORS[doorName]
        if not door then
            error("Could not find door " .. doorName)
        end

        local func = functionTable[command]

        if func == nil then
            error("Could not find the function, probably a typo: " .. command)
        end

        func(door, duration)
    end
end


Events.ConnectForPlayer("ControlDoor", DoorCommand)