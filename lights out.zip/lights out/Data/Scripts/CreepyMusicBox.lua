local API = require(script:GetCustomProperty("API"))

local INTERACTIVE_POINT = script:GetCustomProperty("InteractivePoint"):WaitForObject()
local MUSIC_BOX_CAMERA = script:GetCustomProperty("MusicBoxCamera"):WaitForObject()
local BALLERINA = script:GetCustomProperty("Ballerina"):WaitForObject()
local CAMERA_FINAL_POSITION = script:GetCustomProperty("CameraFinalPosition"):WaitForObject()
local MUSIC = script:GetCustomProperty("Music"):WaitForObject()
local BOY_BEDROOM_DOOR = script:GetCustomProperty("BoyBedroomDoor"):WaitForObject()

local LOCAL_PLAYER = Game.GetLocalPlayer()

local cameraStartPosition = MUSIC_BOX_CAMERA:GetWorldPosition()
local isCameraActive = false
local isInteracting = false

local MIN_PITCH = -1000
local MAX_PITCH = 0
local MIN_VOLUME = 1

local audioTime = time()

math.randomseed(os.time())

Task.Wait()

local CAMERA_INTERPOLATION = _G["cerberus.games.CameraInterpolation"]

function OnPointInteraction(interactivePoint)
    print ("On Print Interaction")
    if INTERACTIVE_POINT == interactivePoint then
        CAMERA_INTERPOLATION.SetOverrideCamera(MUSIC_BOX_CAMERA, 0.2)
        isCameraActive = true
        INTERACTIVE_POINT.context.isEnabled = false
    end
end

function lerp(a, b, t)
    return a * (1-t) + b * t
end

function Tick(dt)
    if isCameraActive then
        while (MUSIC_BOX_CAMERA:GetWorldPosition() - CAMERA_FINAL_POSITION:GetWorldPosition()).size > 1 do
            local newPosition = Vector3.Lerp(MUSIC_BOX_CAMERA:GetWorldPosition(), CAMERA_FINAL_POSITION:GetWorldPosition(), 2 * dt)
            MUSIC_BOX_CAMERA:SetWorldPosition(newPosition)
            Task.Wait()
        end
        isCameraActive = false
        isInteracting = true
    end

    if isInteracting then
        Task.Wait(3)
        audioTime = time()
        while MUSIC.pitch > MIN_PITCH do
            MUSIC.pitch = CoreMath.Lerp(MUSIC.pitch, MIN_PITCH, 2 * dt) - 0.5
            MUSIC:Stop()
            Task.Wait(0.05)
            MUSIC:Play()
        end

        MUSIC.falloff = 2659.351

        Task.Wait(2)
        isInteracting = false

        CAMERA_INTERPOLATION.ClearOverrideCamera(0.1)
        MUSIC_BOX_CAMERA:SetWorldPosition(cameraStartPosition)

        API.SceneStateManager.NextScene()

        API.DoorDriver.Unlock("Boys")
        API.DoorDriver.Shake("Boys")
    end
end



Events.Connect("OnPointInteraction", OnPointInteraction)
