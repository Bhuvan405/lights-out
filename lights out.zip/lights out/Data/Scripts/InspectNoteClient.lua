local API = require(script:GetCustomProperty("API"))

local INTERACTIVE_POINT = script:GetCustomProperty("InteractivePoint"):WaitForObject()


local INSPECT_OBJECT = script:GetCustomProperty("InspectObject"):WaitForObject()
local OFFSET = script:GetCustomProperty("Offset")
local DURATION = script:GetCustomProperty("Duration")

local PANEL = script:GetCustomProperty("Panel"):WaitForObject()
local TRANSPARENT = script:GetCustomProperty("Transparent")

local restPosition = INSPECT_OBJECT:GetWorldPosition()
local restRotation = INSPECT_OBJECT:GetWorldRotation()

local player = Game.GetLocalPlayer()

function SmoothStep(x)
    return x * x * (3 - 2 * x)
 end

function OnPointInteraction(interactivePoint)
    if INTERACTIVE_POINT == interactivePoint then
        PlayScene()
    end
end

local elementOriginalColor = {}

for _, element in pairs(PANEL:GetChildren()) do
    elementOriginalColor[element] = element:GetColor()
    element:SetColor(TRANSPARENT)
end


function LinearFadeIn(element, duration)

    startTime = time()

    while true do
        local t = math.abs(time() - startTime) / duration
        if t > 1 then
            t = 1
        end

        local eColor = Color.Lerp(TRANSPARENT, elementOriginalColor[element], t)
        element:SetColor(eColor)

        if t == 1 then
            return
        end

        Task.Wait()
    end
end

function LinearFadeOut(element, duration)

    startTime = time()

    while true do
        local t = math.abs(time() - startTime) / duration
        if t > 1 then
            t = 1
        end

        local eColor = Color.Lerp(elementOriginalColor[element], TRANSPARENT, t)
        element:SetColor(eColor)

        if t == 1 then
            return
        end

        Task.Wait()
    end
end

function ChangeParentMaintainPositionRotation(coreObject, newParent)
    if Object.IsValid(coreObject) then
        local originalWorldPosition = coreObject:GetWorldPosition()
        local originalWorldRotation = coreObject:GetWorldRotation()

        INSPECT_OBJECT.parent = newParent

        coreObject:SetWorldPosition(originalWorldPosition)
        coreObject:SetWorldRotation(originalWorldRotation)
    else
        warn("ChangeParentMaintainPositionRotation core object is nil, cant change parent")
    end
end

function AttachToLocalViewMaintainWorldPositionRotation(coreObject)
    if Object.IsValid(coreObject) then
        local originalWorldPosition = coreObject:GetWorldPosition()
        local originalWorldRotation = coreObject:GetWorldRotation()

        coreObject:AttachToLocalView()

        coreObject:SetWorldPosition(originalWorldPosition)
        coreObject:SetWorldRotation(originalWorldRotation)
    else
        warn("ChangeParentMaintainPositionRotation core object is nil, cant change parent")
    end
end


function PlayScene()
    local startTime = time()

    INTERACTIVE_POINT.context.isEnabled = false

    local originalParent = INSPECT_OBJECT.parent

    ChangeParentMaintainPositionRotation(INSPECT_OBJECT, nil)

    local duration = DURATION

    API.GameManager.DisableMovement()
    API.GameManager.DisableLook()

    repeat
        local t = math.abs(time() - startTime) / duration
        if t > 1 then
            t = 1
        end
        UpdatePositionAndRotation(t)

        Task.Wait()
    until t == 1

    -- Attach the letter to the camera because we're not gonna keep updating
    UpdatePositionAndRotation(1)
    AttachToLocalViewMaintainWorldPositionRotation(INSPECT_OBJECT)

    --
    -- Bring in UI over the top
    PANEL.visibility = Visibility.FORCE_ON
    for _, element in pairs(PANEL:GetChildren()) do
        LinearFadeIn(element, 1)
        Task.Wait()
    end

    Task.Wait(4)

    -----
    for _, element in pairs(PANEL:GetChildren()) do
        LinearFadeOut(element, 0.5)
        Task.Wait()
    end
    PANEL.visibility = Visibility.FORCE_OFF
    -------
    ChangeParentMaintainPositionRotation(INSPECT_OBJECT, originalParent)

    -- Put the note back again
    duration = DURATION
    startTime = time()
    repeat
        local t = math.abs(time() - startTime) / duration
        if t > 1 then
            t = 1
        end
        UpdatePositionAndRotation(1-t)

        Task.Wait()
    until t == 1
   
    API.GameManager.EnableMovement()
    API.GameManager.EnableLook()

    -- Re-enable interactive point after a delay so the player can read it again if they want
    Task.Wait(1)

    INTERACTIVE_POINT.context.isEnabled = true

    if API.SceneStateManager.GetSceneState() == 2 then
        API.Dialog.Play("Sounds like it was a rough time adjusting..", 1)
        Task.Wait(2)
        API.DoorDriver.Open("Bathroom", 1)
        API.LightDriver.On("Bathroom")
        API.SceneStateManager.NextScene()
    end
    if API.SceneStateManager.GetSceneState() == 5 then
        API.Dialog.Play("I wonder what the father had to hide..", 1)

        -- Just unlock it, dont open it, we can use it
        API.DoorDriver.Unlock("Parents")
        API.SceneStateManager.NextScene()
    end

end

function UpdatePositionAndRotation(r)

    local viewWorldRotation = player:GetViewWorldRotation()

    local worldPosition = player:GetViewWorldPosition() + viewWorldRotation * OFFSET

    r = SmoothStep(r)

    INSPECT_OBJECT:SetWorldPosition(Vector3.Lerp(restPosition, worldPosition, r))

    if Object.IsValid(INSPECT_OBJECT) then
        INSPECT_OBJECT:SetWorldRotation(Rotation.New( Quaternion.Slerp( Quaternion.New(restRotation), Quaternion.New(viewWorldRotation), r)))
    end


end





Events.Connect("OnPointInteraction", OnPointInteraction)