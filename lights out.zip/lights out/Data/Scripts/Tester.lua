-- Task.Wait()
-- local DIALOG_DRIVER  = _G["DialogDriver"]

-- local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()

 
-- --Task.Wait(0.1)

-- Events.Broadcast("ControlLights", "All", "on")


-- function OnBeginOverlap(trigger, other)
--     if other:IsA("Player") then
--         TRIGGER.isEnabled = false
--         Events.Broadcast("ControlLights", "All", "flickeroff")

--         Events.Broadcast("ControlLights", "All", "on")

--         DIALOG_DRIVER.PlayDialog("Huh? Must be the wind..", 2)

--         Events.Broadcast("ControlLights", "All", "on")


--     end
-- end

-- TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)


-- Task.Wait(5)

--Events.BroadcastToServer("ControlDoor", "EntranceDoor", "lockdoor")
--Events.BroadcastToServer("ControlDoor", "EntranceDoor", "opendoor", 2)
--Task.Wait(1)
--Events.BroadcastToServer("ControlDoor", "EntranceDoor", "closedoor", 2)

