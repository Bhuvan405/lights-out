
function OnPlayerJoined(player)
    player:SetVisibility(false, false)
    player.canMount = false
end

Game.playerJoinedEvent:Connect(OnPlayerJoined)