Task.Wait()

local API = require(script:GetCustomProperty("API"))

local PATH = script:GetCustomProperty("GateSequence"):WaitForObject()
local PLAYER_LOOK_ROTATION = script:GetCustomProperty("PlayerLookRotation"):WaitForObject()

function OnStartGame()
    PlayScene()
end

function PlayScene()
    API.HeartBeatDriver.SetHeartRate(API.HeartBeatDriver.RELAXED_BPM)
    Game.GetLocalPlayer():SetLookWorldRotation(PLAYER_LOOK_ROTATION:GetWorldRotation())
    API.CameraSequence.RunCameraSequenceAsync(PATH, 6, 0, 0.5)
    API.GameManager.DisableMovement()
    API.GameManager.DisableLook()
    API.Torch.Off()
    API.Dialog.Play("Phew.. that was a drive and a half.", 1)
    Task.Wait(1)
    API.Dialog.Play("Okay, showtime.", 1)
    Task.Wait(2.37)
    API.DoorDriver.Open("LeftGate", 1)
    API.DoorDriver.Open("RightGate", 1)

    --API.HeartBeatDriver.SetHeartRate(API.HeartBeatDriver.SCARED_BPM)

    Task.Wait(3)
    API.DoorDriver.Close("LeftGate", 1)
    API.DoorDriver.Close("RightGate", 1)
    API.GameManager.EnableLook()
    API.GameManager.EnableMovement()

end

Events.Connect("StartGame", OnStartGame)