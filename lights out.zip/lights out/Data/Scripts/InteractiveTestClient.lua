

local POSITION_DELTA = script:GetCustomProperty("PositionDelta")
local INTERACTIVE_POINT = script:GetCustomProperty("InteractivePoint"):WaitForObject()
local DURATION = script:GetCustomProperty("Duration")


local isOpen = false

local STARTING_POSITION = script.parent:GetPosition()

function OnPointInteraction(interactivePoint)
    print ("On interaction")
    if INTERACTIVE_POINT == interactivePoint then
        isOpen = not isOpen
        if isOpen then
            script.parent:MoveTo(STARTING_POSITION + POSITION_DELTA, DURATION, true)
        else
            script.parent:MoveTo(STARTING_POSITION, DURATION, true)
        end
    end
end

Events.Connect("OnPointInteraction", OnPointInteraction)