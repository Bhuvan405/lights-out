--[[
    SCENE STATE 9 INITIALIZATION
]]--

local API = require(script:GetCustomProperty("API"))

function EnterState()
    API.SkyLightDriver.Dark()
    
    -- Initialize with all lights off
    API.LightDriver.Off("All")
end


return EnterState
