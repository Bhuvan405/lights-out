local API = require(script:GetCustomProperty("API"))

function EnterState()
    API.LightDriver.On("All")
    API.SkyLightDriver.Outside()
    API.DoorDriver.Lock("All")
    Task.Wait(0.2)
    API.DoorDriver.Unlock("Entrance")
end

return EnterState
