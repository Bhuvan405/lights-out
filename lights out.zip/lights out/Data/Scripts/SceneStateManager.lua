_G["cerberus.games.SceneStateManager"] = script.context

local STATES = script:GetCustomProperty("StatesGroup"):WaitForObject()
local STARTING_STATE = script:GetCustomProperty("Root"):WaitForObject():GetCustomProperty("StartingState")
local SCENE_STATES = STATES:GetChildren()

local currentState = STARTING_STATE

for i=1, #SCENE_STATES do
    if i ~= currentState then
        SCENE_STATES[i].isEnabled = false
    end
end

function SafeBroadcastToServer(...)
    local params = {...}
    Task.Spawn( function ()
        local result = nil
        repeat
            result = Events.BroadcastToServer(table.unpack(params))
            Task.Wait(0.2)
        until result == BroadcastEventResultCode.SUCCESS
    end
    )
end

function GetSceneState()
    return currentState
end

function SetSceneState(state)
    local prevState = currentState
    SCENE_STATES[prevState].isEnabled = false
    SCENE_STATES[state].isEnabled = true
    currentState = state

    Events.Broadcast("OnEnterState", state)

    print ("Scene State Manager Client side : " , currentState)
    SafeBroadcastToServer("SceneStateChange", state)
end

function NextScene()
    SetSceneState(currentState + 1)
end

-- At the start of the game, fire off the state we're testing in
SetSceneState(STARTING_STATE)