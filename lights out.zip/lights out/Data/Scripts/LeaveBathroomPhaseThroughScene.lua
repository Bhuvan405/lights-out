local API = require(script:GetCustomProperty("API"))
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()
local DEMON_GROUP = script:GetCustomProperty("DemonGroup"):WaitForObject()
local DEMON_FACE = script:GetCustomProperty("DemonFace"):WaitForObject()

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        PlayScene()
    end
end

function PlayScene()
    API.LightDriver.FlickerOn("LongHall")
    Task.Wait(0.5)
    DEMON_GROUP:RotateTo(Rotation.New(37,0,0), 1)
    Task.Wait(1.5)
    DEMON_GROUP:RotateTo(Rotation.New(0,0,0), 1)
    API.Dialog.Play("Is anyone there?!?", 1)
    --API.WaitUntilOnScreen(DEMON_FACE:GetWorldPosition())
    DEMON_GROUP.isEnabled = false
end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)