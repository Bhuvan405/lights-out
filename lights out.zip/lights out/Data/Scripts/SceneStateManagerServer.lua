local STATES = script:GetCustomProperty("StatesGroup"):WaitForObject()
local STARTING_STATE = script:GetCustomProperty("Root"):WaitForObject():GetCustomProperty("StartingState")
local SCENE_STATES = STATES:GetChildren()

local currentState = STARTING_STATE

print ("Current state = ".. currentState)

for i=1, #SCENE_STATES do
    if i ~= currentState then
        SCENE_STATES[i].isEnabled = false
    end
end

function OnSceneStateChange(player, state)
    SCENE_STATES[currentState].isEnabled = false
    SCENE_STATES[state].isEnabled = true
    currentState = state
    print ("Scene State Manager Server: " , currentState)
end

Events.ConnectForPlayer("SceneStateChange", OnSceneStateChange)