_G["cerberus.games.CursorClient"] = script.context

local CURSOR = script:GetCustomProperty("Cursor"):WaitForObject()

function ShowCursor()
    CURSOR.visibility = Visibility.FORCE_ON
    UI.SetCanCursorInteractWithUI(true)
    UI.SetCursorVisible(false)
end

function HideCursor()
    CURSOR.visibility = Visibility.FORCE_OFF
    UI.SetCanCursorInteractWithUI(false)
    UI.SetCursorVisible(false)
end

function Tick()
    CURSOR.x = UI.GetCursorPosition().x
    CURSOR.y = UI.GetCursorPosition().y
end

CURSOR.visibility = Visibility.FORCE_OFF