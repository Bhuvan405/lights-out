_G["cerberus.games.HeartBeatDriver"] = script.context

local API = require(script:GetCustomProperty("API"))

local HEART_BEAT_SOUND = script:GetCustomProperty("HeartBeatSound")
local LOCAL_PLAYER = Game.GetLocalPlayer()
local BLUR_POST_PROCESS = script:GetCustomProperty("RadialBlurPostProcess"):WaitForObject()


while not Object.IsValid(LOCAL_PLAYER) do
    LOCAL_PLAYER = Game.GetLocalPlayer()
end

-- In some spots, we'll make the volume bigger because we're in silence

local timeLeftUntilNextBeat = 0

local targetHeartBPM = 77.6
local targetVolume = 0.2

local heartBeatVolume = targetVolume
local heartBPM = targetHeartBPM


local effectStrength = 0
local targetEffectStrength = 0

SCARED_BPM = 130 -- dont set this to local, we need it global to expose it to other API
RELAXED_BPM = 77.6 -- dont set this to local, we need it global to expose it to other API
ANXIOUS_BPM = 105.0 -- dont set this to local, we need it global to expose it to other API

function InverseLerp(a, b, v)
    return CoreMath.Clamp((v-a) / (b-a),0,1)
end

function SetHeartRate(bpm)
    targetHeartBPM = bpm
    targetVolume = CoreMath.Lerp(0.5, 4, InverseLerp(RELAXED_BPM, SCARED_BPM, bpm))
    print("Setting volume to " , targetVolume)
end

function PlayHeartBeat(volume)
    local beat = World.SpawnAsset(HEART_BEAT_SOUND)
    beat:AttachToLocalView()
    -- change volume
    beat.volume = volume

    -- change pitch
    beat.pitch = 100

    -- play the sound
    beat:Play()
end

function PlayScreenEffect()
    -- BOOM! Fancy Effects!
    --Effect Strength
    targetEffectStrength = 1.5
end


function Tick(dt)
    heartBeatVolume = CoreMath.Lerp(targetVolume, heartBeatVolume, 0.5 ^ (dt*2))
    heartBPM = CoreMath.Lerp(targetHeartBPM, heartBPM, 0.5 ^ (dt*2))

    local beatsPerMinutes = heartBPM

    timeLeftUntilNextBeat = timeLeftUntilNextBeat - dt
    if timeLeftUntilNextBeat <= 0 then
        if API.SceneStateManager.GetSceneState() < 10 then
            PlayHeartBeat(heartBeatVolume)
        else
            PlayHeartBeat(heartBeatVolume * 0.4)
        end
        
        PlayScreenEffect()

        --print(heartBeatVolume)
        local delay = 60 / beatsPerMinutes
        timeLeftUntilNextBeat = timeLeftUntilNextBeat + delay
    end

    targetEffectStrength = CoreMath.Lerp(0, targetEffectStrength, 0.5 ^ (dt*2))
    effectStrength = CoreMath.Lerp(targetEffectStrength, effectStrength, 0.5 ^ (dt*40) )
    --print (effectStrength)

    
    BLUR_POST_PROCESS:SetSmartProperty("Effect Strength", effectStrength * 1.5 * ((heartBeatVolume-0.5)/3))

end

