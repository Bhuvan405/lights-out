_G["cerberus.games.Torch"] = script.context

local SPOT_LIGHT = script:GetCustomProperty("Spotlight"):WaitForObject()
local CLICK_SOUND = script:GetCustomProperty("ClickSound"):WaitForObject()

local lastCommand = nil
local overrideTorch = false
local torchValue = 0

local silentClick = false

function SilentClick(isEnabled)
    silentClick = isEnabled
end

function DoControlTorch(func)
    if func == "forceon" then
        On()
    end
    if func == "forceoff" then
        Off()
    end
    if func == "default" then
        Default()
    end
end

function On()
    if torchValue ~= 1 and not silentClick then
        -- play sound
        CLICK_SOUND:Play()
    end
    overrideTorch = true
    torchValue = 1
end

function Off()
    if torchValue ~= 0 and not silentClick then
        -- play sound
        CLICK_SOUND:Play()
    end
    overrideTorch = true
    torchValue = 0
end

function Default()
    overrideTorch = false
end

Events.Connect("ControlTorch", DoControlTorch)

Task.Wait()

PLAYER_LOCATION = _G["cerberus.games.PlayerLocation"]
LIGHT_DRIVER = _G["cerberus.games.LightDriver"]


local isTorchOn = false
local originalLightIntensity = SPOT_LIGHT.intensity
SPOT_LIGHT.intensity = 0


function Tick(dt)
    currentRoom = PLAYER_LOCATION.GetCurrentRoomName()

    local turnTorchOn = false -- on by default if we're outside

    if currentRoom then
        local lightOn = LIGHT_DRIVER.GetRoomState(currentRoom)
        turnTorchOn = not lightOn
    end

    if overrideTorch == false then
        torchValue = 0
        if turnTorchOn then
            torchValue = 1
        end
    end

    SPOT_LIGHT.intensity = CoreMath.Lerp(torchValue * originalLightIntensity , SPOT_LIGHT.intensity, 0.5 ^ (dt*60))
end