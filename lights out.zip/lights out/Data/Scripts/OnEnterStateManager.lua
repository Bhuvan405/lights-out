
function OnEnterState(state)
    -- One line of code written by Fear, if we're confused by this later it's his fault :D
    require(script:GetCustomProperty("SceneState"..state))()
end

Events.Connect("OnEnterState", OnEnterState)