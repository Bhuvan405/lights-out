function ManagePlayer(player, func, value)

    if func == "walkSpeed" then
        player.maxWalkSpeed = 320 * value
    end

    if func == "movement" then
        if value then
            player.movementControlMode = MovementControlMode.VIEW_RELATIVE
        else
            player.movementControlMode = MovementControlMode.NONE
        end
    end

    if func == "look" then
        if value then
            player.lookControlMode = LookControlMode.RELATIVE
        else
            player.lookControlMode = LookControlMode.NONE
        end
    end

    if func == "position" then
        print ("Setting the player position")
        player:SetWorldPosition(value)
    end

    if func == "throw" then
        player:SetVelocity(value)
    end
end

Events.ConnectForPlayer("ManagePlayer", ManagePlayer)