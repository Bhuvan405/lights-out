local MAIN_MENU_CAMERA = script:GetCustomProperty("Camera"):WaitForObject()
local LOCAL_PLAYER = Game.GetLocalPlayer()
local PLAY_BUTTON = script:GetCustomProperty("PlayButton"):WaitForObject()
local UI_PANEL = script:GetCustomProperty("UIPanel"):WaitForObject()
local MUSIC = script:GetCustomProperty("Music"):WaitForObject()

function OnPlayerJoined(player)
    print ("On player joined callback from MenuCamera")
    _G["cerberus.games.CursorClient"].ShowCursor()

    if  player == LOCAL_PLAYER then
        Events.Broadcast("ControlLights", "Girls", "flickerforever")
        player:SetOverrideCamera(MAIN_MENU_CAMERA)
    end
end 



Game.playerJoinedEvent:Connect(OnPlayerJoined)




local API = require(script:GetCustomProperty("API"))

function OnPlayPressed()
    LOCAL_PLAYER:ClearOverrideCamera()
    MUSIC:Stop()
    Events.Broadcast("ControlLights", "Girls", "on")
    UI_PANEL.isEnabled = false
    _G["cerberus.games.CursorClient"].HideCursor()

    if API.SceneStateManager.GetSceneState() == 1 then
        print("Start game!")
        Events.BroadcastToServer("ManagePlayer", "init", true)
        Events.Broadcast("Introduction")
    else
        --
    end
end

PLAY_BUTTON.clickedEvent:Connect(OnPlayPressed)