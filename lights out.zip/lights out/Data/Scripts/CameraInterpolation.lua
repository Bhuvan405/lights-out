_G["cerberus.games.CameraInterpolation"] = script.context

player = Game.GetLocalPlayer()

local OVERRIDE_CAMERA = script:GetCustomProperty("Camera"):WaitForObject()

local speed = 0
local time = 0
local isinterpolating = false
local cameraReference = nil

function SmoothStep(x)
    return x * x * (3 - 2 * x)
 end

function SetOverrideCamera(camera, duration)
    cameraReference = camera
    player:SetOverrideCamera(OVERRIDE_CAMERA)
    RefreshOverrideCamera()
    speed = 1 / duration
    isinterpolating = true
end

function ClearOverrideCamera(duration)
    speed = -1/duration
end


function RefreshOverrideCamera()
    r = SmoothStep(time)
    playerCamera = player:GetDefaultCamera()
    player:GetViewWorldPosition()
    OVERRIDE_CAMERA:AttachToPlayer(player, "camera")
    OVERRIDE_CAMERA:SetPosition(playerCamera:GetPositionOffset())
    local playerPosition = OVERRIDE_CAMERA:GetWorldPosition()
    OVERRIDE_CAMERA:Detach()

    local worldPosition = Vector3.Lerp(playerPosition, cameraReference:GetWorldPosition(), r)
    local worldRotation = Rotation.New(Quaternion.Slerp(Quaternion.New(player:GetLookWorldRotation()), Quaternion.New(cameraReference:GetWorldRotation()), r))
    local currentDistance = CoreMath.Lerp(playerCamera.currentDistance, cameraReference.currentDistance, r)
    local fieldOfView = CoreMath.Lerp(playerCamera.fieldOfView, cameraReference.fieldOfView, r)

    OVERRIDE_CAMERA:SetWorldPosition(worldPosition)
    OVERRIDE_CAMERA:SetWorldRotation(worldRotation)
    OVERRIDE_CAMERA.currentDistance = currentDistance
    OVERRIDE_CAMERA.fieldOfView = fieldOfView
end

function Tick(dt)
    if isinterpolating then
        time = time + dt * speed
        if speed > 0 then
            if time > 1 then
                time = 1
            end
        else
            if time < 0 then
                time = 0
                player:ClearOverrideCamera()
                isinterpolating = false
            end
        end
        RefreshOverrideCamera()
    end
end