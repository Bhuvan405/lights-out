local API = require(script:GetCustomProperty("API"))
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()
local PORCH_LIGHT_FX = script:GetCustomProperty("PorchLightFX"):WaitForObject()
local PORCH_LIGHT = script:GetCustomProperty("PorchLight"):WaitForObject()

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        PlayScene()
    end
end

function PlayScene()
   -- API.HeartBeatDriver.SetHeartRate(API.HeartBeatDriver.SCARED_BPM)

    API.LightDriver.Off(PORCH_LIGHT)

    for _, e in pairs(PORCH_LIGHT_FX:GetChildren()) do
        e:Play()
    end

    Task.Wait(1)

    --API.HeartBeatDriver.SetHeartRate(API.HeartBeatDriver.RELAXED_BPM)
end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)