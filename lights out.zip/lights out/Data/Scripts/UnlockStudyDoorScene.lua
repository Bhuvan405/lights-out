local API = require(script:GetCustomProperty("API"))
local INTERACTIVE_POINT = script:GetCustomProperty("InteractivePoint"):WaitForObject()

function OnPointInteraction(interactivePoint)
    if INTERACTIVE_POINT == interactivePoint then
        API.DoorDriver.Open("LeftStudy", 1)
        API.DoorDriver.Open("RightStudy", 1)

        INTERACTIVE_POINT.context.isEnabled = false

        API.SceneStateManager.NextScene()
    end
end

Events.Connect("OnPointInteraction", OnPointInteraction)