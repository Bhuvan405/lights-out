local API = require(script:GetCustomProperty("API"))
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()

local DEMON_STILL_1 = script:GetCustomProperty("DemonStill1"):WaitForObject()
local DEMON_STILL_2 = script:GetCustomProperty("DemonStill2"):WaitForObject()
local DEMON_RUN_AT_YOU = script:GetCustomProperty("DemonRunAtYou"):WaitForObject()
local DEMON_RUN_AT_YOU_TARGET = script:GetCustomProperty("DemonRunAtYouTarget"):WaitForObject()
local DEMON_ON_FACE_JUMP_SCARE = script:GetCustomProperty("DemonOnFaceJumpScare"):WaitForObject()
local JUMP_SCARE_SOUND = script:GetCustomProperty("JumpScareSound"):WaitForObject()

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        PlayScene()
    end
end

function Initialize()
    DEMON_STILL_1.isEnabled = false
    DEMON_STILL_2.isEnabled = false
    DEMON_RUN_AT_YOU.isEnabled = false
    DEMON_ON_FACE_JUMP_SCARE.isEnabled = false
end

Initialize()

function FlickerTheGodDamnLightHack()
    Task.Wait(0.01)
    API.Torch.On()
    Task.Wait(0.03)
    API.Torch.Off()
end

function PlayScene()

    API.GameManager.ChangeWalkSpeed(0.3)

    API.LightDriver.Off("All")
    API.LightDriver.FlickerOff("LongHall")
    API.LightDriver.Off("MoonLights")

    API.Torch.SilentClick(true)
    local torchHack = Task.Spawn(FlickerTheGodDamnLightHack)
    torchHack.repeatCount = -1
    torchHack.repeatInterval = 0.04

    DEMON_STILL_1.isEnabled = true
    Task.Wait(1.3)
    DEMON_STILL_1.isEnabled = false

    Task.Wait(1.3)
    
    DEMON_STILL_2.isEnabled = true
    Task.Wait(2)
    DEMON_STILL_2.isEnabled = false

    Task.Wait(3)

    DEMON_RUN_AT_YOU.isEnabled = true
    local duration = 1
    DEMON_RUN_AT_YOU:MoveTo(DEMON_RUN_AT_YOU_TARGET:GetWorldPosition(), duration, false)
    Task.Wait(1)

    DEMON_RUN_AT_YOU.isEnabled = false
    API.GameManager.DisableMovement()
    torchHack:Cancel()
    API.Torch.Off()

    Task.Wait(math.random(2,12))

    API.GameManager.EnableMovement()
    
    -- The demon that waits for you and then attacks your face
    API.Torch.On()
    API.Torch.SilentClick(false)

    DEMON_ON_FACE_JUMP_SCARE.isEnabled = true
    DEMON_ON_FACE_JUMP_SCARE:AttachToLocalView()

    -- Increase the volume on jump scare
    JUMP_SCARE_SOUND.volume = 10
    JUMP_SCARE_SOUND:Play()
    Task.Wait(0.2)

    API.Torch.Off()
    Task.Wait(0.2)
    DEMON_ON_FACE_JUMP_SCARE.isEnabled = false

    Task.Wait(1)
    API.HeartBeatDriver.SetHeartRate(API.HeartBeatDriver.SCARED_BPM)
    Task.Wait(2)

    API.Torch.Default()

    API.GameManager.ChangeWalkSpeed(1)

    Task.Wait(1)

    API.HeartBeatDriver.SetHeartRate(API.HeartBeatDriver.RELAXED_BPM)
end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)
