local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        Events.Broadcast("Credits")
    end
end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)