_G["cerberus.games.SkyLightDriver"] = script.context

local SKY_LIGHT = script:GetCustomProperty("Skylight"):WaitForObject()
local smoothedIntensity = 0

local DARK_INTENSITY = script:GetCustomProperty("DarkIntensity")
local OUTSIDE_INTENSITY = script:GetCustomProperty("OutsideIntensity")
local INSIDE_INTENSITY = script:GetCustomProperty("InsideIntensity")

local targetIntensity = OUTSIDE_INTENSITY

function Inside()
    targetIntensity = INSIDE_INTENSITY
end

function Outside()
    targetIntensity = OUTSIDE_INTENSITY
end

function Dark()
    targetIntensity = DARK_INTENSITY
end

function Tick(dt)
    smoothedIntensity = CoreMath.Lerp(targetIntensity, smoothedIntensity, 0.5 ^ (dt*20))

    SKY_LIGHT:SetSmartProperty("Intensity", smoothedIntensity)
end
