local ROOT = script:GetCustomProperty("Root"):WaitForObject()
local PROMT_TEXT = script:GetCustomProperty("PromptText"):WaitForObject()
local PROMPT_SFX = script:GetCustomProperty("PromptSFX"):WaitForObject()

local CHAR_WAIT_TIME = script:GetCustomProperty("CharTypeWait")
local PROMPT_END_TIME = script:GetCustomProperty("NextPromptDelay")

local PROMPTS = ROOT:GetCustomProperties()

local prompt_list = {}

for propName, propValue in pairs(PROMPTS) do
    prompt_list[tonumber(propName)] = propValue
end

-- Update the displayed prompt
function UpdatePrompt(message, current, final)
    PROMT_TEXT.text = message
    PROMPT_SFX:Play()
    Task.Wait(CHAR_WAIT_TIME)
    PromptByChar(current, final)
end

-- Add another letter to the string each time it is called till the string has been finished.
function PromptByChar(current_string, final_string)
    if #current_string < #final_string then
        current_string = current_string .. string.sub(final_string, #current_string + 1, #current_string +1)
        UpdatePrompt(current_string, current_string, final_string)
    else
        return true
    end
end

for _, prompt in pairs(prompt_list) do
    PromptByChar("", prompt)
    Task.Wait(PROMPT_END_TIME)
end

Events.Broadcast("PromptFinished")