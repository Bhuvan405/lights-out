--[[
    SCENE STATE 5 INITIALIZATION
]]--

local API = require(script:GetCustomProperty("API"))

function EnterState()
    API.SkyLightDriver.Dark()

    API.DoorDriver.Lock("LeftStudy")
    API.DoorDriver.Lock("RightStudy")

    -- Initialize with all lights off
    API.LightDriver.Off("All")
    
end


return EnterState
