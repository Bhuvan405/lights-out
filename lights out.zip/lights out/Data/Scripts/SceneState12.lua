local PREVIOUS_MUSIC = script:GetCustomProperty("PreviousMusic"):WaitForObject()

--[[
    SCENE STATE 12 INITIALIZATION
]]--

local API = require(script:GetCustomProperty("API"))

function EnterState()
    PREVIOUS_MUSIC:FadeOut(1)

    API.SkyLightDriver.Outside()

    API.GameManager.ChangeWalkSpeed(1)

    API.LightDriver.FlickerForever("All")

    Task.Wait(6)
    -- Initialize with all lights off

    API.LightDriver.Off("All")
    API.LightDriver.On("Main Gate")


end


return EnterState
