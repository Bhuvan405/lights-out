local TRIGGER = script.parent:GetCustomProperty("Trigger"):WaitForObject()
--local INSPECT_OBJECT = script.parent:GetCustomProperty("InspectObject"):WaitForObject()
local OFFSET = script.parent:GetCustomProperty("Offset")

isInspecting = false
inputPressedBinding = {}

TRIGGER.interactedEvent:Connect(
    function(trigger, player)

        print("Interaction happened")
        isInspecting = true

        trigger.isEnabled = false

       player.movementControlMode = MovementControlMode.NONE

       inputPressedBinding[player] = player.bindingPressedEvent:Connect(OnInputPressed)

    end
)







function OnInputPressed(player, input)
    if input == "ability_extra_33" then
        isInspecting = false
        player.movementControlMode = MovementControlMode.VIEW_RELATIVE
        inputPressedBinding[player]:Disconnect()

        Task.Wait(1)
        TRIGGER.isEnabled = true
    end
end

