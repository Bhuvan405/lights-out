local POSITION_DELTA = script:GetCustomProperty("PositionDelta")
local ROTATION_DELTA = script:GetCustomProperty("RotationDelta")
local INTERACTION_POINT = script:GetCustomProperty("InteractionPoint"):WaitForObject()
local CHILD_TRIGGER = script:GetCustomProperty("ChildTrigger"):WaitForObject()

local DURATION = script:GetCustomProperty("Duration")
local ROOT = script.parent

local OPEN_LABEL = script:GetCustomProperty("OpenLabel")
local CLOSE_LABEL = script:GetCustomProperty("CloseLabel")
local LABEL = script:GetCustomProperty("Label")

local OPEN_SOUND = script:GetCustomProperty("OpenSound"):WaitForObject()
local CLOSE_SOUND = script:GetCustomProperty("CloseSound"):WaitForObject()

-- Initialize child to be disabled.
CHILD_TRIGGER.isEnabled = false

local isOpen = false

local STARTING_POSITION = ROOT:GetPosition()
local STARTING_ROTATION = ROOT:GetRotation()

-- This is a global for allowing closing. By default, have it set to false if theres something to enable after opening it
allowClosing = not Object.IsValid(CHILD_TRIGGER)

function OpenDraw()
    ROOT:MoveTo(STARTING_POSITION + POSITION_DELTA, DURATION, true)
    ROOT:RotateTo(STARTING_ROTATION + ROTATION_DELTA, DURATION, true)

    if Object.IsValid(OPEN_SOUND) then
        OPEN_SOUND:Play()
    end
end

function CloseDraw()
    ROOT:MoveTo(STARTING_POSITION, DURATION, true)
    ROOT:RotateTo(STARTING_ROTATION + ROTATION_DELTA, DURATION, false)

    if isOpen then
        if Object.IsValid(CHILD_TRIGGER) then
            CHILD_TRIGGER.isEnabled = false
        end
    end

    if Object.IsValid(OPEN_SOUND) then
        CLOSE_SOUND:Play()
    end
end


function OnPointInteraction(interactivePoint)
    print ("On interaction")
    if INTERACTION_POINT == interactivePoint then
        isOpen = not isOpen

        INTERACTION_POINT.context.isEnabled = false

        if isOpen then
            OpenDraw()
        else
            CloseDraw()
        end

        Task.Wait(DURATION)

        if isOpen then
            if Object.IsValid(CHILD_TRIGGER) then
                CHILD_TRIGGER.isEnabled = true
            end
        end

        if allowClosing then
            INTERACTION_POINT.context.isEnabled = true
        end

        UpdateLabel()
    end
end

function UpdateLabel()
    if not isOpen then
        INTERACTION_POINT.context.SetLabel(OPEN_LABEL.. " " ..LABEL)
    else
        INTERACTION_POINT.context.SetLabel(CLOSE_LABEL.." "..LABEL)
    end
end

-- Update the label
--UpdateLabel()

Events.Connect("OnPointInteraction", OnPointInteraction)