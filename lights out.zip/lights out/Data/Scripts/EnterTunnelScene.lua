local API = require(script:GetCustomProperty("API"))
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        PlayScene()
    end
end


function PlayScene()
    API.SkyLightDriver.Outside()

    Events.BroadcastToServer("MoveBookShelf", false)
    -- Play sound of bookshelf sliding back

    API.LightDriver.On("Basement")

end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)

