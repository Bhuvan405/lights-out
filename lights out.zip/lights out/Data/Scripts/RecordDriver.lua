local RECORD_CIRCLE = script:GetCustomProperty("RecordCircle"):WaitForObject()
local TIME_STAMP = script:GetCustomProperty("Timestamp"):WaitForObject()
local DATE_TEXT = script:GetCustomProperty("Date"):WaitForObject()

local LOCAL_PLAYER = Game.GetLocalPlayer()
local startTime = time()


local Blink = Task.Spawn(function()
    if RECORD_CIRCLE.visibility == Visibility.FORCE_OFF then
        RECORD_CIRCLE.visibility = Visibility.FORCE_ON
    else 
        RECORD_CIRCLE.visibility = Visibility.FORCE_OFF
    end
end)

Blink.repeatCount = -1
Blink.repeatInterval = 1

function Pad(n)
    if n < 10 then
        return "0"..tostring(math.floor(n))

    else
        return tostring(math.floor(n))
    end
end

local tock = 0

function Tick(dt)
    local duration = time() - startTime

    local hours = (duration / 3600)
    local minutes = (duration % 3600 / 60)
    local seconds = (duration % 3600 % 60)

    local testIt = os.date('%m-%d-%Y %H:%M:%S',os.time())

    DATE_TEXT.text = testIt
    TIME_STAMP.text = Pad(hours)..":"..Pad(minutes)..":"..Pad(seconds)
end 

function OnPlayerJoined(player)
    if player == LOCAL_PLAYER then
        startTime = time()
    end
end

function OnStartGame()

    
end


Events.Connect("StartGame", OnStartGame)

Game.playerJoinedEvent:Connect(OnPlayerJoined)