Task.Wait()
local API = require(script:GetCustomProperty("API"))
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()
local BATHTUB_LIGHT = script:GetCustomProperty("BathtubLight"):WaitForObject()


 -- Force the torch off
Events.Broadcast("ControlTorch", "forceoff")

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false

        -- Flicker the dining room light
        --API.LightDriver.FlickerOn("Dining")

        -- What the fuck happened in here.. looks like it was a struggle.
        API.Dialog.Play("Looks like there was a struggle in here..", 1)
        
        -- Turn on the bathroom lights
        API.LightDriver.FlickerOn("Bathroom")

        -- Turn off kitchen and family room
        API.LightDriver.FlickerOn("Kitchen")
        
        Task.Wait(0.5)

        -- Entrance hall turned on
        API.LightDriver.On("EntranceHall")

        Task.Wait(2)

        API.LightDriver.FlickerOn("EntranceHall")
    end
end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)