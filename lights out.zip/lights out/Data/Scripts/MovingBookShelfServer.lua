local BOOKSHELF = script:GetCustomProperty("MovingBookshelf"):WaitForObject()

function MoveBookshelf(player, revealBasement)
    print ("Moving the bookshelf")
    if revealBasement then
        BOOKSHELF:MoveTo(Vector3.New(-2884.88, 481.766, -182.199), 1, true)
    else
        BOOKSHELF:MoveTo(Vector3.New(-3092.038, 481.766, -182.199), 1, true)
    end
end





Events.ConnectForPlayer("MoveBookShelf", MoveBookshelf)