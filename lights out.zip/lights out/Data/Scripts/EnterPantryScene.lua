local API = require(script:GetCustomProperty("API"))
local SHELF_IMPACT_SOUND = script:GetCustomProperty("ShelfImpactSound"):WaitForObject()

function SafeBroadcastToServer(...)
    local params = {...}
    Task.Spawn( function ()
        local result = nil
        repeat
            result = Events.BroadcastToServer(table.unpack(params))
            Task.Wait(0.2)
        until result == BroadcastEventResultCode.SUCCESS
    end
    )
end

Task.Wait()

local DIALOG_DRIVER = _G["cerberus.games.DialogDriver"]

local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()
local SHELF = script:GetCustomProperty("Shelf"):WaitForObject()
local SHELF_TARGET = script:GetCustomProperty("ShelfTarget"):WaitForObject()
local SHELF_COLLISION_REF = script:GetCustomProperty("ShelfCollision")
local SHELF_COLLISION_AFTER_REF = script:GetCustomProperty("ShelfCollisionAfter")

SafeBroadcastToServer("ChangeCoreObjectSetting", SHELF_COLLISION_REF, "IsEnabled", false)

function Prepare()
    SafeBroadcastToServer("ChangeCoreObjectSetting", SHELF_COLLISION_REF, "IsEnabled", true)
    SafeBroadcastToServer("ChangeCoreObjectSetting", SHELF_COLLISION_AFTER_REF, "IsEnabled", false)
end
Prepare()


function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        ActScene()
    end
end



------------------------------------------------
function ActScene()
    --Server command for SHELF_COLLISION.isEnabled = false

    SafeBroadcastToServer("ChangeCoreObjectSetting", SHELF_COLLISION_REF, "IsEnabled", false)
    SafeBroadcastToServer("ChangeCoreObjectSetting", SHELF_COLLISION_AFTER_REF, "IsEnabled", true)

    --Server command for SHELF_COLLISION_AFTER.isEnabled = true

    local shelfMoveDuration = 1
    SHELF:MoveTo(SHELF_TARGET:GetWorldPosition(), shelfMoveDuration, false)
    SHELF:RotateTo(SHELF_TARGET:GetWorldRotation(), shelfMoveDuration, false)

    Task.Wait(0.5)
    SHELF_IMPACT_SOUND:Play()

    -- The parent room needs unlocking at this point

    API.SceneStateManager.NextScene()
    


end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)
