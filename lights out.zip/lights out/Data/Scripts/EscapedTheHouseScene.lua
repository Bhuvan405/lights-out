local API = require(script:GetCustomProperty("API"))
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        PlayScene()
    end
end


function PlayScene()
    API.SceneStateManager.NextScene()
    API.Torch.Off()
    Events.Broadcast("Camera Shake", 0)
    API.HeartBeatDriver.SetHeartRate(API.HeartBeatDriver.RELAXED_BPM)
end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)

