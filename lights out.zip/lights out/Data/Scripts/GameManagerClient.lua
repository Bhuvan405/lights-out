_G["cerberus.games.GameManager"] = script.context

function SafeBroadcastToServer(...)
    local params = {...}
    Task.Spawn( function ()
        local result = nil
        repeat
            result = Events.BroadcastToServer(table.unpack(params))
            Task.Wait(0.2)
        until result == BroadcastEventResultCode.SUCCESS
    end
    )
end

function ChangeWalkSpeed(multiplier)
    ManagePlayer("walkSpeed", multiplier)
end

function EnableMovement()
    ManagePlayer("movement", true)
end

function DisableMovement()
    ManagePlayer("movement", false)
end

function EnableLook()
    ManagePlayer("look", true)
end

function DisableLook()
    ManagePlayer("look", false)
end

function Init()
    ManagePlayer("init")
end

function SetPosition(value)
    ManagePlayer("position", value)
end

function Throw(value)
    ManagePlayer("throw", value)
end

function ManagePlayer(func, value)
    SafeBroadcastToServer("ManagePlayer", func, value)
end