-- Gets a module registered to the global table, waiting until its found
function GetModule(name)
    local module = _G[name]

    if module ~= nil then
        return module
    end

    startTime = time()
    repeat
        print("waiting for ..." .. name)
        Task.Wait()
        module = _G[name]
    until module ~= nil

    return module
end


local DIALOG_DRIVER = GetModule("cerberus.games.DialogDriver")
local SCENE_STATE_MANAGER = GetModule("cerberus.games.SceneStateManager")
local CAMERA_INTERPOLATION = GetModule("cerberus.games.CameraInterpolation")
local CAMERA_SEQUENCE = GetModule("cerberus.games.CameraSequence")
local LIGHT_DRIVER = GetModule("cerberus.games.LightDriver")
local DOOR_DRIVER = GetModule("cerberus.games.DoorDriver")
local TORCH = GetModule("cerberus.games.Torch")
local GAME_MANAGER = GetModule("cerberus.games.GameManager")
local SKY_LIGHT_DRIVER = GetModule("cerberus.games.SkyLightDriver")
local HEART_BEAT_DRIVER = GetModule("cerberus.games.HeartBeatDriver")
local CURSOR_DRIVER = GetModule("cerberus.games.CursorClient")


function IsOnScreen(position)
    position = UI.GetScreenPosition(position)
    if position then
        position = (position / UI.GetScreenSize()) - (Vector2.ONE * 0.5)
        if math.abs(position.x) < 0.5 and math.abs(position.y) < 0.5 then
            return true
        end
    end
    return false
end

function WaitUntilOnScreen(position)
    while not IsOnScreen(position) do Task.Wait() end
end

function SafeBroadcastToServer(...)
    local params = {...}
    Task.Spawn( function ()
        local result = nil
        repeat
            result = Events.BroadcastToServer(table.unpack(params))
            Task.Wait(0.2)
        until result == BroadcastEventResultCode.SUCCESS
    end
    )
end



API = {}
API.Dialog = DIALOG_DRIVER
API.SceneStateManager = SCENE_STATE_MANAGER
API.CameraInterpolation = CAMERA_INTERPOLATION
API.CameraSequence= CAMERA_SEQUENCE
API.LightDriver = LIGHT_DRIVER
API.DoorDriver = DOOR_DRIVER
API.Torch = TORCH
API.GameManager = GAME_MANAGER
API.SkyLightDriver = SKY_LIGHT_DRIVER
API.HeartBeatDriver = HEART_BEAT_DRIVER
API.CursorDriver = CURSOR_DRIVER


API.WaitUntilOnScreen = WaitUntilOnScreen
API.SafeBroadcastToServer = SafeBroadcastToServer



return API