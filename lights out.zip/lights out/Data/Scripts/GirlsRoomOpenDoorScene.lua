local API = require(script:GetCustomProperty("API"))
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()
local MUSIC = script:GetCustomProperty("Music"):WaitForObject()


function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        PlayScene()
    end
end

function PlayScene()
    MUSIC:Play()
    API.DoorDriver.Open("Girls", 1)

    Task.Wait(1)
    API.Dialog.Play("Is anyone in there?!?", 1)
end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)