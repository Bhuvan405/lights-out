--[[
    SCENE STATE 4 INITIALIZATION
]]--

local API = require(script:GetCustomProperty("API"))

function EnterState()
    -- Initialize with all lights off
    API.SkyLightDriver.Inside()
    API.LightDriver.Off("All")
    API.LightDriver.On("Bathroom")
    API.LightDriver.On("LongHall")
 
    API.DoorDriver.Lock("LeftStudy")
    Task.Wait(0.2)
    API.DoorDriver.Lock("RightStudy")
    Task.Wait(0.2)
    API.DoorDriver.Lock("Boys")
    Task.Wait(0.2)
    API.DoorDriver.Lock("Parents")

    Task.Wait(2)

    API.Torch.On()
end

return EnterState
