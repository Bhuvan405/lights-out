local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()
local CHAIR_START = script:GetCustomProperty("ChairStart"):WaitForObject()
local CHAIR = script:GetCustomProperty("Chair"):WaitForObject()
local CHAIR_SLIDE_SOUND = script:GetCustomProperty("ChairSlideSound"):WaitForObject()

Task.Wait()
local API = require(script:GetCustomProperty("API"))

local startPos = CHAIR_START:GetWorldPosition()
local endPos = CHAIR:GetWorldPosition()
local startRotation = CHAIR_START:GetWorldRotation()
local endRotation = CHAIR:GetWorldRotation()

CHAIR:SetWorldPosition(startPos)
CHAIR:SetWorldRotation(startRotation)

function OnBeginOverlap(whichTrigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        PlayScene()
	end
end


function SlerpRotation(startRotation, endRotation, r)
    return Rotation.New( Quaternion.Slerp(Quaternion.New(startRotation), Quaternion.New(endRotation), r) )
end

-- API: Example of moving a chair
function MoveChairSequence()

    local duration = 0.5

    local startTime = time()

    local finished = false

    CHAIR_SLIDE_SOUND:Play()

    repeat
        local r = math.abs(time() - startTime) / duration

        if r > 1 then
            r = 1
            finished = true
        end

        r = 1 - ((1-r) ^ 2)

        local position = Vector3.Lerp(startPos, endPos, r)

        --position = position + Vector3.UP * math.sin(r * math.pi) * 200
        local rotation = SlerpRotation(startRotation, endRotation, r)

        CHAIR:SetWorldPosition(position)
        CHAIR:SetWorldRotation(rotation)
        Task.Wait()
    until finished

end

--
function PlayScene()
    API.GameManager.DisableMovement()
    API.Dialog.Play("Hello? Is there anyone here?", 1)
    API.LightDriver.FlickerOn("Boys")
    Task.Wait(1)
    MoveChairSequence()
    --API.LightDriver.FlickerOff("Boys")
    Task.Wait(1)
    API.Dialog.Play("What the?..", 1)
    API.GameManager.EnableMovement()
    API.LightDriver.FlickerOn("Boys")
    API.DoorDriver.Close("Boys", 0.5)
end


TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)