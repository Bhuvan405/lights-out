local API = require(script:GetCustomProperty("API"))
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()
local BOOKSHELF = script:GetCustomProperty("Bookshelf"):WaitForObject()
local BOOK_SPAWNER = script:GetCustomProperty("BookSpawner"):WaitForObject()

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        PlayScene()
    end
end

function FlickerTheGodDamnLightHack()
    Task.Wait(0.01)
    API.Torch.On()
    Task.Wait(0.03)
    API.Torch.Off()
end


function PlayScene()
    API.DoorDriver.Lock("LeftStudy")
    API.DoorDriver.Lock("RightStudy")
    API.SkyLightDriver.Inside()

    API.LightDriver.FlickerForever("Study")

    API.Torch.SilentClick(true)

    local torchHack = Task.Spawn(FlickerTheGodDamnLightHack)
    torchHack.repeatCount = -1
    torchHack.repeatInterval = 0.04
    
    print ("Play scene")

    Task.Wait(1)

    torchHack:Cancel()
    API.Torch.On()
    API.Torch.SilentClick(false)
    API.LightDriver.On("Study")

    Task.Wait(2)

    BOOK_SPAWNER.context.RunBookSequence()
end


function InspectedItemPutBack()
    if (API.SceneStateManager.GetSceneState() == 9) then
        Events.BroadcastToServer("MoveBookShelf", true)

        Task.Wait(1) -- Takes 1 second for the book shelf to actually move I FlickerTheGodDamnLightHack

        API.Dialog.Play("This must be what the father was hiding...")

        API.SceneStateManager.NextScene()
    end
end



TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)
Events.Connect("InspectedItemPutBack", InspectedItemPutBack)
