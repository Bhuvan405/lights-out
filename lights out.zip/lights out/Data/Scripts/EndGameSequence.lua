local API = require(script:GetCustomProperty("API"))
local CAMERA = script:GetCustomProperty("Camera"):WaitForObject()
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()
local END_GAME_MUSIC = script:GetCustomProperty("EndGameMusic"):WaitForObject()


local nodes = nil
local numNodes = nil
local currentNodeIndex = nil
local node = nil
local player = nil
local prevPosition = nil
local nextPosition = nil
local nodeDistance = nil
local speed = nil
local currentDistance = nil
local smoothPosition = nil
local smootherPosition = nil
local allowTicking = false

function StartSequence()


    API.GameManager.DisableMovement()
    API.GameManager.DisableLook()

    nodes = script:GetChildren()
    numNodes = #nodes

    currentNodeIndex = 2

    node = nodes[currentNodeIndex]

    prevPosition = nodes[1]:GetWorldPosition()
    nextPosition = nodes[currentNodeIndex]:GetWorldPosition()

    nodeDistance = (nextPosition - prevPosition).size

    speed = 0
    currentDistance = 0

     API.CameraInterpolation.SetOverrideCamera(CAMERA, 0.3)

    smoothPosition = prevPosition + node:GetWorldRotation() * Vector3.FORWARD * 100
    smootherPosition = prevPosition + node:GetWorldRotation() * Vector3.FORWARD * 800

    allowTicking = true

    AdjustSpeedAsync()

    API.DoorDriver.Open("Entrance")
    API.LightDriver.On("All")
   
    Task.Wait(3.3)


    Task.Wait(5-3.3)

 
    END_GAME_MUSIC:Play()

    print("Starting clock..")
    local endTime = time()

    Task.Wait(3)
    Task.Wait(5)

    API.DoorDriver.Close("Entrance", 0.2)
    print("Total delay: ", math.abs(time() - endTime))
    API.LightDriver.Off("All")

    Task.Wait(0.35)

    API.SkyLightDriver.Dark()

    Task.Wait(1)

    END_GAME_MUSIC:FadeOut(1)


    Events.Broadcast("Credits")
    

 
end


function ClampMagnitude(vector, max)
    if vector.size > max then
        return vector:GetNormalized() * max
    else
        return vector
    end
end

function MoveTowards(vector, target, minDistance, maxDistance)
    delta = (vector - target)
    local size = CoreMath.Clamp(delta.size, minDistance, maxDistance)
    return target + delta:GetNormalized() * size
end

function AdjustSpeedAsync()
    Task.Spawn(AdjustSpeed)
end

function AdjustSpeed()
    speed = 0
    Task.Wait(3)
    speed = 300
    Task.Wait(0.2)
    for i=0, 10 do
        speed = speed - 30
        Task.Wait(0.03)
    end
    speed = 0
    Task.Wait(1)
    speed = 300
    Task.Wait(0.2)
    for i=0, 10 do
        speed = speed - 30
        Task.Wait(0.03)
    end
    speed = 0

    Task.Wait(5)
    speed = 6000
end


function Tick(dt)
    if not allowTicking then
        return
    end

   -- speed = speed + 1000 * dt
    currentDistance = currentDistance + speed * dt

    if currentDistance > nodeDistance then
        if numNodes == currentNodeIndex then
            currentDistance = nodeDistance
        else
            NextNode()
        end
    end

    local r = currentDistance / nodeDistance
    local currentPosition = Vector3.Lerp(prevPosition, nextPosition, r)

    --smoothPosition = Vector3.Lerp(currentPosition, smoothPosition, 0.5 ^ (dt*10))
    --smootherPosition = Vector3.Lerp(smoothPosition, smootherPosition, 0.5 ^ (dt*10))

    smoothPosition = MoveTowards(smoothPosition, currentPosition, 0, 100)
    smootherPosition = MoveTowards(smootherPosition, currentPosition, 0, 800)

    CAMERA:SetWorldPosition(smoothPosition)
    CAMERA:SetWorldRotation( Rotation.New(smootherPosition - smoothPosition + Vector3.UP * 200, Vector3.UP))
end

function NextNode()
    currentDistance = currentDistance-nodeDistance
    currentNodeIndex = currentNodeIndex + 1
    prevPosition = nextPosition;
    node = nodes[currentNodeIndex]
    nextPosition = node:GetWorldPosition()
    nodeDistance = (nextPosition - prevPosition).size
end

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        StartSequence()
    end
end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)