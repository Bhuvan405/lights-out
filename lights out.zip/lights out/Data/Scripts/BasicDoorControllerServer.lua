-- Internal custom properties
local COMPONENT_ROOT = script:GetCustomProperty("ComponentRoot"):WaitForObject()
local ROTATION_ROOT = script:GetCustomProperty("RotationRoot"):WaitForObject()
local ROTATING_TRIGGER = script:GetCustomProperty("RotatingTrigger"):WaitForObject()
local CLIENT_CONTEXT = script:GetCustomProperty("ClientContext"):WaitForObject()
local INVERT = script:GetCustomProperty("Invert")

-- User exposed properties
local DEFAULT_DURATION = COMPONENT_ROOT:GetCustomProperty("Duration")

-- Check user properties
if DEFAULT_DURATION == nil or DEFAULT_DURATION < 0 then
	DEFAULT_DURATION = 0.2
end

-- Variables
-- Rotation is 1.0 for +90 degree rotation, 0.0 for closed, -1.0, for -90 degree rotation
local targetDoorRotation = 0.0


local isLocked = false
local isShaking = false
local delay = 0


-- Snap instantly to the given rotation
function SetCurrentRotation(rotation)
	targetDoorRotation = rotation
	ROTATION_ROOT:SetRotation(Rotation.New(0.0, 0.0, 90.0 * rotation * boolToSign(not INVERT)))
end

function boolToSign(value)
	if value then return 1 else return -1 end
end

-- Sets the rotation that the door should move to (at SPEED)
function SetTargetRotation(rotation, duration)
	targetDoorRotation = rotation
	ROTATION_ROOT:RotateTo(Rotation.New(0.0, 0.0, 90.0 * rotation * boolToSign(not INVERT)), duration, true)
end

function OpenDoor(duration)
	if not duration then
		duration = DEFAULT_DURATION
	end
	CLIENT_CONTEXT:SetNetworkedCustomProperty("Volume", 1)
	if duration == nil then
		duration = DEFAULT_DURATION
	end
	SetTargetRotation(1, duration)
	isShaking = false
end

function CloseDoor(duration)
	if not duration then
		duration = DEFAULT_DURATION
	end
	CLIENT_CONTEXT:SetNetworkedCustomProperty("Volume", 1)
	SetTargetRotation(0, duration)
	isShaking = false
end

function SilentlyCloseDoor(duration)
	if not duration then
		duration = DEFAULT_DURATION
	end
	CLIENT_CONTEXT:SetNetworkedCustomProperty("Volume", 0)
	SetTargetRotation(0.0)
	isShaking = false
end

function SilentlyOpenDoor(duration)
	if not duration then
		duration = DEFAULT_DURATION
	end
	CLIENT_CONTEXT:SetNetworkedCustomProperty("Volume", 0)
	SetTargetRotation(1.0, duration)
	isShaking = false
end

function ShakeDoor()
	isShaking = true
end

function StopDoorShake()
	isShaking = false
end

function InstantlyCloseDoor()
	SetTargetRotation(0)
end

function InstantlyOpenDoor()
	SetTargetRotation(1)
end

-- Makes door be un-opennable
function LockDoor()
	print("LOCK DOOR CALLED")
	isLocked = true
end

function UnlockDoor()
	isLocked = false
end

function GetDoorCurrentRotation()
	return ROTATION_ROOT:GetWorldRotation().z / 90.0
end

-- Opens the door away from the given player
function OpenDoorPushed(player)
	if delay > time() then
		return
	end

	local geoQuaternion = Quaternion.New(ROTATION_ROOT:GetWorldRotation())
	local relativeX = geoQuaternion:GetForwardVector()
	local playerOffset = player:GetWorldPosition() - ROTATION_ROOT:GetWorldPosition()

	if INVERT then
		playerOffset = -playerOffset
	end

	local hardPush = false
	local amount = 0.5

	local duration = DEFAULT_DURATION

	if math.abs(player:GetVelocity() .. relativeX) > 200 then
		hardPush = true
		amount = 1
	end

	print ("AM I LOCKED ? ", isLocked)
	if not isLocked then
		-- Figure out which direction is away from the player
		if playerOffset .. relativeX > 0.0 then
			if targetDoorRotation < 0 then
				SetTargetRotation(0, duration)
			else
				SetTargetRotation( CoreMath.Clamp(targetDoorRotation + amount, -1, 1), duration)
			end

			delay = time() + duration
		end
	end


end


-- nil OnBeginOverlap(Trigger, CoreObject)
-- Handles the player overlapping if AutoOpen is true
function OnBeginOverlap(trigger, other)
	if other:IsA("Player") then
		OpenDoorPushed(other)
	end
end

-- nil Tick(float)
-- Handle closing the door with AutoOpen, and changing interaction label back to open
function Tick(deltaTime)
	if isShaking then
		SetTargetRotation( CoreMath.Lerp(-0.1, 0.3, math.random()), 0.2)
		Task.Wait(0.2)
	else
		for _, player in pairs(Game.GetPlayers()) do
			if ROTATING_TRIGGER:IsOverlapping(player) then
				OpenDoorPushed(player)
			end
		end
	end
	Task.Wait(0.05)
end

if Object.IsValid(ROTATING_TRIGGER) then
	ROTATING_TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)
	ROTATING_TRIGGER.isInteractable = false
end




