_G["cerberus.games.CameraSequence"] = script.context

local CAMERA = script:GetCustomProperty("Camera"):WaitForObject()
local SPEED = script:GetCustomProperty("Speed")

function GetModule(name)
    local module = _G[name]

    if module ~= nil then
        return module
    end

    startTime = time()
    repeat
        print("waiting for ..." .. name)
        Task.Wait()
        module = _G[name]
    until module ~= nil

    return module
end

-- Get the module for camera interpolation, wait if we have to!
CameraInterpolation = GetModule("cerberus.games.CameraInterpolation")

-- Clamp the size of the vector
function ClampMagnitude(vector, max)
    if vector.size > max then
        return vector:GetNormalized() * max
    else
        return vector
    end
end

-- Ease from a position to another
function MoveTowards(vector, target, minDistance, maxDistance)
    delta = (vector - target)
    local size = CoreMath.Clamp(delta.size, minDistance, maxDistance)
    return target + delta:GetNormalized() * size
end

function RunCameraSequenceAsync(path, startDelay, fadeIn, fadeOut)
    Task.Spawn( function() RunCameraSequence(path, startDelay, fadeIn, fadeOut) end )
end

function RunCameraSequence(path, startDelay, fadeIn, fadeOut)
    local nodes = path:GetChildren()
    local numNodes = #nodes

    print ("Running sequence")

    --Set Overide the camera
    CameraInterpolation.SetOverrideCamera(CAMERA, fadeIn)

    local currentNodeIndex = 2

    -- Initialize the first nodes
    local prevPosition = nodes[currentNodeIndex-1]:GetWorldPosition()
    local nextPosition = nodes[currentNodeIndex]:GetWorldPosition()

    local prevRotation = Quaternion.New(nodes[currentNodeIndex-1]:GetWorldRotation())
    local nextRotation = Quaternion.New(nodes[currentNodeIndex]:GetWorldRotation())

    local smoothPosition = Vector3.New(prevPosition)
    local smootherPosition = Vector3.New(prevPosition)

    local smoothRotation = Quaternion.New(prevRotation)

    local speed = SPEED
    local currentDistance = 0

    local player = Game.GetLocalPlayer()

    local nodeDistance = (nextPosition - prevPosition).size

    CAMERA:SetWorldPosition(prevPosition)
    CAMERA:SetWorldRotation(Rotation.New(prevRotation))

    Task.Wait(startDelay)

    local prevTime = time()

    local finished = false
    repeat
        local dt = time() - prevTime
        prevTime = time()

        currentDistance = currentDistance + speed * dt

        if currentDistance > nodeDistance then
            if currentNodeIndex == numNodes then
                currentDistance = nodeDistance
                finished = true
            else
                currentDistance = 0
                currentNodeIndex = currentNodeIndex + 1
                print(currentNodeIndex)

                prevPosition = Vector3.New(nextPosition)
                prevRotation = Quaternion.New(nextRotation)

                local node = nodes[currentNodeIndex]
                nextPosition = node:GetWorldPosition()
                nextRotation = Quaternion.New(node:GetWorldRotation())
                nodeDistance = (nextPosition - prevPosition).size
            end
        end

        local r = currentDistance / nodeDistance

        local currentPosition = Vector3.Lerp(prevPosition, nextPosition, r)
        
        local currentRotation = Quaternion.Slerp(prevRotation, nextRotation, r)

        smoothPosition = Vector3.Lerp(currentPosition, smoothPosition, 0.5 ^ (dt * 20))
        smootherPosition = Vector3.Lerp(smoothPosition, smootherPosition, 0.5 ^ (dt * 20))
        smoothRotation = Quaternion.Slerp(currentRotation, smoothRotation, 0.5 ^ (dt * 20))

        CAMERA:SetWorldPosition(currentPosition)
        CAMERA:SetWorldRotation(Rotation.New(smoothRotation))

        Task.Wait()
    until finished
    CameraInterpolation.ClearOverrideCamera(fadeOut)
end

Events.Connect("CameraSequence", RunCameraSequence)