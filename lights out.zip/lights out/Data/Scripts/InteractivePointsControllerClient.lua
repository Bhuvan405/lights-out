_G["cerberus.games.InteractivePoints"] = script.context

print("Registered InteractivePointsClient")

local ICONGROUP = script:GetCustomProperty("IconGroup"):WaitForObject()
local ICONTEMPLATE = script:GetCustomProperty("IconTemplate")
local INTERACTION_MESSAGE = script:GetCustomProperty("InteractionMessage"):WaitForObject()
local INTERACTION_MESSAGE_TEXT = INTERACTION_MESSAGE:GetCustomProperty("Text"):WaitForObject()

local icons = {}

local highlightedNode = nil

function OnBindingPressed(whichPlayer, binding)
    if binding == "ability_primary" then
        if highlightedNode then
            Events.Broadcast("OnPointInteraction", highlightedNode.target)
        end
    end
end


Game.GetLocalPlayer().bindingPressedEvent:Connect(OnBindingPressed)


function AddPointOfInterest(object)
    local spawnedIcon = World.SpawnAsset(ICONTEMPLATE, {parent = ICONGROUP})
    local info = {}
    info.target = object
    info.icon = spawnedIcon
    icons[object] = info
end

function RemovePointOfInterest(object)
    local info = icons[object]
    if info then
        icons[object] = nil

        info.icon:Destroy()
        info.icon = nil
        info.target = nil
    end
end

function Tick()

    local closest = nil
    local closestDistance = nil

    for _, info in pairs(icons) do
        if info.target.context.IsEnabled() then
            local screenPosition = UI.GetScreenPosition(info.target:GetWorldPosition())

            if screenPosition then
                info.icon.isEnabled = true
                info.icon.x = screenPosition.x
                info.icon.y = screenPosition.y

                local centered = (screenPosition / UI.GetScreenSize()) - (Vector2.ONE * 0.5)

                if centered.size < 0.3 then
                    local color = info.icon:GetColor()
                    color.a = 1
                    info.icon:SetColor(color)

                    if closestDistance then
                        if closestDistance > centered.size then
                            closest = info
                            closestDistance = centered.size
                        end
                    else
                        closest = info
                        closestDistance = centered.size
                    end

                end

                local color = info.icon:GetColor()
                color.a = 0.3
                info.icon:SetColor(color)


            else -- icon is behind us
                info.icon.isEnabled = false
            end
        else -- not enabled
            info.icon.isEnabled = false
        end

    end

    if closest then
        INTERACTION_MESSAGE.isEnabled = true
        INTERACTION_MESSAGE_TEXT.text = closest.target.context.GetLabel()

        local color = closest.icon:GetColor()
        color.a = 1
        closest.icon:SetColor(color)

        local screenPosition = UI.GetScreenPosition(closest.target:GetWorldPosition())
        INTERACTION_MESSAGE.x = screenPosition.x
        INTERACTION_MESSAGE.y = screenPosition.y

        highlightedNode = closest

    else
        INTERACTION_MESSAGE.isEnabled = false
        highlightedNode = nil
    end
end