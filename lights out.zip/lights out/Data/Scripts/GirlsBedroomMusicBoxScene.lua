local propTrigger = script:GetCustomProperty("Trigger"):WaitForObject()
local propRockingHorse = script:GetCustomProperty("RockingHorse"):WaitForObject()

