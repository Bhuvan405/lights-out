local STUDY_DOOR_LEFT = script:GetCustomProperty("StudyDoorLeft"):WaitForObject()
local STUDY_DOOR_RIGHT = script:GetCustomProperty("StudyDoorRight"):WaitForObject()

local duration = 1

function OnOpenReading(player)
    STUDY_DOOR_LEFT:RotateTo(Rotation.New(0, 0, 90), duration)
    STUDY_DOOR_RIGHT:RotateTo(Rotation.New(0,0,-90), duration)
end


function OnCloseReading(player)
    STUDY_DOOR_LEFT:RotateTo(Rotation.New(0, 0, 0), duration)
    STUDY_DOOR_RIGHT:RotateTo(Rotation.New(0,0,0), duration)
end

Events.ConnectForPlayer("OpenFuckingReading", OnOpenReading)
Events.ConnectForPlayer("CloseFuckingReading", OnCloseReading)