_G["cerberus.games.DialogDriver"] = script.context

local DIALOG_TEXT = script:GetCustomProperty("DialogText"):WaitForObject()
local TYPE_RATE = script:GetCustomProperty("TypeRate")
local LOCAL_PLAYER = Game.GetLocalPlayer()

DIALOG_TEXT.text = ""

-- new function thats cleaner
function Play(msg, delay)
    --msg = LOCAL_PLAYER.name..": "..msg

    for i = 1, string.len(msg) do
        DIALOG_TEXT.text = string.sub(msg, 1, i)
        Task.Wait(TYPE_RATE)
    end
    Task.Wait(delay)
    DIALOG_TEXT.text = ""

end