function OnPlayerJoined(player)
	player:SetVisibility(false)
end

-- on player joined/left functions need to be defined before calling event:Connect()
Game.playerJoinedEvent:Connect(OnPlayerJoined)
