local SCREENS = script:GetCustomProperty("Screens"):WaitForObject()
local TRANSPARENT = script:GetCustomProperty("Transparent")
local INITIAL_DELAY = SCREENS:GetCustomProperty("InitialDelay")


function LinearFadeOut(group, duration)

    startTime = time()
    local elementChildren = {}
 
    for _, element in pairs(group:GetChildren()) do
        if element:IsA("UIImage") or element:IsA("UIText") then
            elementChildren[element] = element:GetColor()
        end
    end

    while true do
        local t = math.abs(time() - startTime) / duration
        if t > 1 then
            t = 1
        end

        for element, elementOriginalColor in pairs(elementChildren) do         
            local eColor = Color.Lerp(elementOriginalColor, TRANSPARENT, t)
            element:SetColor(eColor)
        end

        if t == 1 then
            return
        end

        Task.Wait()
    end
end

function OnCredits()
    SCREENS.visibility = Visibility.FORCE_ON

    Task.Wait(INITIAL_DELAY)
    local slides = SCREENS:GetChildren()
    
    for i = #slides, 1, -1 do
        local smartSound = slides[i]:FindChildByType("SmartAudio")
        local sound = slides[i]:FindChildByType("Audio")
        local delay = slides[i]:GetCustomProperty("Delay")
        local duration = slides[i]:GetCustomProperty("Duration")

        if sound then
            sound:Play()
        end

        if smartSound then
            smartSound:Play()
        end

        Task.Wait(delay)
        LinearFadeOut(slides[i], duration)
    end
end

Events.Connect("Credits", OnCredits)