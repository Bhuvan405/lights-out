local API = require(script:GetCustomProperty("API"))
local INTERACTIVE_POINT = script:GetCustomProperty("InteractivePoint"):WaitForObject()
local PENTAGRAM_DRIVER = script:GetCustomProperty("PentagramDriver"):WaitForObject()
local FOG = script:GetCustomProperty("Fog"):WaitForObject()


function OnPointInteraction(interactivePoint)
    if INTERACTIVE_POINT == interactivePoint then
        print ("We have interacted with the knife!")
        INTERACTIVE_POINT.context.isEnabled = false
        FOG.isEnabled = false

        Events.Broadcast("Camera Shake")

        PENTAGRAM_DRIVER.context.PlayFireSequenceAsync()

        API.SceneStateManager.NextScene()
    end
end

Events.Connect("OnPointInteraction", OnPointInteraction)