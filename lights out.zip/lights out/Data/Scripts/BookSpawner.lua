local BOOK_PHYSICS_TEMPLATE = script:GetCustomProperty("BookPhysicsTemplate")

local BOOK_ART_GROUP_1 = script:GetCustomProperty("Books"):WaitForObject()
local BOOK_ART_GROUP_2 = script:GetCustomProperty("BooksOnFearsShelf"):WaitForObject()

local BOOKART_TO_PHYSICS_TRANSFORM = Transform.New(Rotation.New(0, 0, 90), Vector3.New(0.347, -29.95, -34.985), Vector3.ONE )
local BOOK_WOOSH_SOUND = script:GetCustomProperty("BookWooshSound")

-- note the book scale is 0.121

local isTicking = false
local totalTime = 0
local books = {}

function RunBookSequence()
    local count = 0

    -- Get all the books in the group
    bookPlaceholders1 = BOOK_ART_GROUP_1:GetChildren()
    bookPlaceholders2 = BOOK_ART_GROUP_2:GetChildren()

    -- Copy all the books into another table
    booksToSpawn = {}
    for _, book in ipairs(bookPlaceholders1) do
        print (book.name)
        table.insert(booksToSpawn, book)
    end
    for _, book in ipairs(bookPlaceholders2) do
        print (book.name)
        table.insert(booksToSpawn, book)
    end

    -- Keep turning a random book into a physics book
    while #booksToSpawn > 0 do
        local numBook = math.random(1, #booksToSpawn)
        local artBook = booksToSpawn[numBook]
        artBook.isEnabled = false

        table.remove(booksToSpawn, numBook)

        local location = BOOKART_TO_PHYSICS_TRANSFORM * artBook:GetWorldTransform()

        -- Spawn a woosh sound
        sound = World.SpawnAsset(BOOK_WOOSH_SOUND, {
            position = artBook:GetWorldPosition()
        })

        -- Physics
        physics = World.SpawnAsset(BOOK_PHYSICS_TEMPLATE, {
            position = location:GetPosition(),
            rotation = location:GetRotation(),
            scale = Vector3.ONE * 0.121
           })

        Task.Wait()

        local delta = Game.GetLocalPlayer():GetWorldPosition() - physics:GetWorldPosition()
        delta = delta:GetNormalized() * 2500 + Vector3.UP * 500

        physics:SetVelocity(delta)
        Task.Wait(0.1)
        physics:SetVelocity(delta)

        table.insert(books, physics)
    end

    isTicking = true
end


function Tick(dt)
    if isTicking then
        totalTime = totalTime + dt

        if totalTime > 2 then
            for _, book in ipairs(books) do
                v = book:GetVelocity()
                v = v + Vector3.UP * dt * 980 * 2
                book:SetVelocity(v)
            end
        end

        if totalTime > 4 then
            isTicking = false
        end

    end
end