local API = require(script:GetCustomProperty("API"))
local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()


function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        PlayScene()
    end
end

function PlayScene()
    API.DoorDriver.Open("Boys", 2)
    Task.Wait(1)
    API.Dialog.Play("There's a strong presence here...whatever this thing is, it's angry..", 1)
end


TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)

