-- This is a script I wrote so we can broadcast to the server and do certain operations on an object with some simple API
-- A suggestion for the future - if people hacked the broadcast to do stuff, provide another script that can validate if then
-- thing you want to change is 'allowed'


CAN_CHANGE_IS_ENABLED = script:GetCustomProperty("IsEnabled") -- bool or nil
TARGET = script:GetCustomProperty("Target"):WaitForObject(5)

if TARGET == nil then
    error("Target is null on ChangeCoreObjectSettingListenerServer")
end

function OnChangeCoreObjectSettingCalled(player, coreObjectReference, property, value)
    if coreObjectReference.id == TARGET.id then
        if property == "IsEnable" then
            if CAN_CHANGE_IS_ENABLED then
                script.parent.isEnabled = TARGET
            end
        end
    end
end

Events.ConnectForPlayer("ChangeCoreObjectSetting", OnChangeCoreObjectSettingCalled)


