--[[
    SCENE STATE 6 INITIALIZATION
]]--

local API = require(script:GetCustomProperty("API"))

function EnterState()
    API.SkyLightDriver.Dark()

    API.DoorDriver.Open("Boys", 1)

    Task.Wait(1)

    -- Initialize with all lights off
    API.LightDriver.Off("All")
    API.SkyLightDriver.Dark()

    Task.Wait(1)
    API.Torch.Default()
    
    Task.Wait(1)
    API.DoorDriver.Lock("LeftStudy")
    API.DoorDriver.Lock("RightStudy")
end


return EnterState
