_G["cerberus.games.LightDriver"] = script.context

local ROOT = script:GetCustomProperty("Root"):WaitForObject()
local ON_COLOR = script:GetCustomProperty("OnColor")
local OFF_COLOR = script:GetCustomProperty("OffColor")

--[[
New Usage
API.LightDriver.On("Bathroom")


Usage:
Events.Broadcast("ControlLights", "Bathroom", "flickeron")

-------------------------
functions
---------------------
flickeron
flickeroff
off
on
flickerforever

----------------
List of rooms:
-----------------
Main Gate
Main Yard
Porch
EntranceHall
Reading
Dining
Family
Kitchen
Bathroom
LongHall
ShortHall
BrokenHall
Girls
Boys
Parents

All

-----------------------

-----------------------


 ]]



local ROOMS = {}
local roomState = {}

for _, room in pairs(ROOT:GetChildren()) do
    ROOMS[room.name] = room
    -- By default, all the lights are on
    roomState[room.name] = true
end

local lightOriginalIntensity = {}
local flickerForever = {}

function SetLightIntensity(light, value)
    light.intensity = value * lightOriginalIntensity[light]

    for _, element in pairs(light:GetChildren()) do
        if element:IsA("CoreObject") then
             element:SetColor( Color.Lerp(OFF_COLOR, ON_COLOR, value))
        end
    end

end

function InitializeLights()
    local allLights = World.FindObjectsByType("Light")
    
    for _, light in pairs(allLights) do
        lightOriginalIntensity[light] = light.intensity
    end
end

InitializeLights()

function InternalFlicker(light)
    flickerForever[light] = false
    Task.Wait(0.01)
    SetLightIntensity(light, 0)
    Task.Wait(0.05)
    SetLightIntensity(light, 1)
    Task.Wait(0.03)
    SetLightIntensity(light, math.random() )
    Task.Wait(0.01)
    SetLightIntensity(light, 1)
    Task.Wait(0.01)
    SetLightIntensity(light, 0)
    Task.Wait(0.05)
    SetLightIntensity(light, 1)
    Task.Wait(0.03)
    SetLightIntensity(light, math.random() )
    Task.Wait(0.05)
    SetLightIntensity(light, 1)
end

function InternalFlickerOn(light)
    flickerForever[light] = false
    Task.Wait(0.01)
    SetLightIntensity(light , 0)
    Task.Wait(0.05)
    SetLightIntensity(light , 1)
    Task.Wait(0.03)
    SetLightIntensity(light , math.random())
    Task.Wait(0.01)
    SetLightIntensity(light , 1)
    Task.Wait(0.01)
    SetLightIntensity(light , 0)
    Task.Wait(0.05)
    SetLightIntensity(light , math.random())
    Task.Wait(0.03)
    SetLightIntensity(light , math.random())
    Task.Wait(0.05)
    SetLightIntensity(light , 1)
end

function InternalFlickerOff(light)
    flickerForever[light] = false
    Task.Wait(0.01)
    SetLightIntensity(light , 0)
    Task.Wait(0.05)
    SetLightIntensity(light , 1)
    Task.Wait(0.03)
    SetLightIntensity(light , math.random())
    Task.Wait(0.01)
    SetLightIntensity(light , 1)
    Task.Wait(0.01)
    SetLightIntensity(light , 0)
    Task.Wait(0.05)
    SetLightIntensity(light , math.random())
    Task.Wait(0.03)
    SetLightIntensity(light , math.random())
    Task.Wait(0.05)
    SetLightIntensity(light , 0)
end

function InternalFlickerForever(light)
    while(flickerForever[light]) do
        for i=1, 2 do
            Task.Wait(0.05)
            SetLightIntensity(light , math.random())
            Task.Wait(0.02)
            SetLightIntensity(light , math.random())
            Task.Wait(0.01)
            SetLightIntensity(light , math.random())
            Task.Wait(0.02)
            SetLightIntensity(light , 0)
            Task.Wait(0.08)
            SetLightIntensity(light , math.random())
            Task.Wait(0.08)
            SetLightIntensity(light , math.random())
            Task.Wait(0.09)
            SetLightIntensity(light , math.random())
            Task.Wait(0.1)
            SetLightIntensity(light , math.random())
            Task.Wait(0.02)
            SetLightIntensity(light , math.random())
            Task.Wait(0.01)
            SetLightIntensity(light , math.random())
            Task.Wait(0.02)
            SetLightIntensity(light , 0)
            Task.Wait(0.08)
            SetLightIntensity(light , math.random())
            Task.Wait(0.08)
            SetLightIntensity(light , math.random())
            Task.Wait(0.09)
            SetLightIntensity(light , math.random())
            Task.Wait(0.1)
        end
    end
end

function InternalOn(light)
     SetLightIntensity(light, 1)
     flickerForever[light] = false
end

function InternalOff(light)
    SetLightIntensity(light, 0)
    flickerForever[light] = false
end

function LightController(light, func)
    if func == "flickeron" then
        Task.Spawn(function()
            InternalFlickerOn(light)
        end)
    end

    if func == "flickeroff" then
        Task.Spawn(function()
            InternalFlickerOff(light)
        end)
    end

    if func == "off" then
        InternalOff(light)
    end

    if func == "on" then
        InternalOn(light)
    end

    if func == "flickerforever" then
        flickerForever[light] = true
        Task.Spawn(function()
            InternalFlickerForever(light)
        end)
    end
end

function ControlLights(room, func)
    if room == "All" then -- Household Wide
        for _, room in pairs(ROOMS) do
            SetRoomState(room.name, func)
            local lights = ROOMS[room.name]:GetChildren()

            for _, light in pairs(lights) do
                LightController(light, func)
            end
        end
    else     -- Individual Rooms
        local lights = ROOMS[room]:GetChildren()

        SetRoomState(room, func)

        for _, light in pairs(lights) do
            LightController(light, func)
        end
    end
end

function SetRoomState(room, func)
    local roomLightOn = false
    if func == "flickeron" then
        roomLightOn = true
    end

    if func == "flickeroff" then
        roomLightOn = false
    end

    if func == "off" then
        roomLightOn = false
    end

    if func == "on" then
        roomLightOn = true
    end

    if func == "flickerforever" then
        roomLightOn = true
    end

    roomState[room] = roomLightOn
end

function GetRoomState(room)
    return roomState[room]
end

function ControlLight(light, func)
    LightController(light, func)
end

--------------------

-- Turns a light, or a room (by string) on
function On(name)
    if type(name) ~= "string" then
        if name:IsA("Light") then
            InternalOn(name)
        else
            error(name .. " is not a light")
        end
    else
        print ("Turning light on " .. name)
        ControlLights(name, "on")
    end
end

-- Turns a light, or a room (by string) off
function Off(name)
    if type(name) ~= "string" then
        if name:IsA("Light") then
            InternalOff(name)
        else
            error(name .. " is not a light")
        end
    else
        ControlLights(name, "off")
    end
end

-- Makes a light, or a room (by string) flicker on
function FlickerOn(name)
    if type(name) ~= "string" then
        if name:IsA("Light") then
            LightController(name, "flickeron")
        else
            error(name .. " is not a light")
        end
    else
        ControlLights(name, "flickeron")
    end
end

-- Makes a light, or a room (by string) flicker off
function FlickerOff(name)
    if type(name) ~= "string" then
        if name:IsA("Light") then
            LightController(name, "flickeroff")
        else
            error(name .. " is not a light")
        end
    else
        ControlLights(name, "flickeroff")
    end
end

-- Makes a light, or a room (by string) flicker forever
function FlickerForever(name)
    if type(name) ~= "string" then
        if name:IsA("Light") then
            print ("We are flicking the light " .. name.name)
            LightController(name, "flickerforever")
        else
            error(name .. " is not a light")
        end
    else
        ControlLights(name, "flickerforever")
    end
end

Events.Connect("ControlLights", ControlLights)
Events.Connect("ControlLight", ControlLight)