local API = require(script:GetCustomProperty("API"))
local ROOT = script:GetCustomProperty("Root"):WaitForObject()

local INTERMISSION = ROOT:GetCustomProperty("Intermission")
local DIALOG = ROOT:GetCustomProperty("Dialog")
local DIALOG_SUSTAIN = ROOT:GetCustomProperty("DialogSustain")
local TRIGGER = ROOT:GetCustomProperty("Trigger"):WaitForObject()
local RETRIGGERABLE = ROOT:GetCustomProperty("Retriggerable")

local startTime = nil

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        if RETRIGGERABLE then
            PlayDialog()
        else
            TRIGGER.isEnabled = false
            PlayDialog()
        end
    end
end

function PlayDialog()
    if startTime == nil or time() - startTime > INTERMISSION then
        startTime = time()
        API.Dialog.Play(DIALOG, DIALOG_SUSTAIN)
    end
end


TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)