--[[
    SCENE STATE 10 INITIALIZATION
]]--


local API = require(script:GetCustomProperty("API"))

function EnterState()
    API.SkyLightDriver.Dark()
    
    -- Initialize with all lights off
    API.LightDriver.Off("All")

    -- We should initialize the book shelf to be in the new position, but i guess that would require a broadcast :/

    -- Make the player run! Or maybe have some dialog

end


return EnterState
