-- Example usage
-- API.DoorDriver.OpenDoor("door", duration)
-- API.DoorDriver.CloseDoor()

_G["cerberus.games.DoorDriver"] = script.context

function SafeBroadcastToServer(...)
    local params = {...}
    Task.Spawn( function ()
        local result = nil
        repeat
            result = Events.BroadcastToServer(table.unpack(params))
            Task.Wait(0.2)
        until result == BroadcastEventResultCode.SUCCESS
    end
    )
end

function Open(door, duration)
 --   SafeBroadcastToServer("ControlDoor", door, cmd, duration)
    ControlDoors(door, "opendoor", duration)
end

function Close(door, duration)
    ControlDoors(door, "closedoor", duration)
end

function Lock(door)
    ControlDoors(door, "lockdoor")
end

function Unlock(door)
    ControlDoors(door, "unlockdoor")
end

function Shake(door)
    ControlDoors(door, "shakedoor")
end

function ControlDoors(door, cmd, duration)
    print("Broading the door as ", door, cmd, duration)
    SafeBroadcastToServer("ControlDoor", door, cmd, duration)
end