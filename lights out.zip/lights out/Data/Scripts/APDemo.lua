local TRIGGER = script:GetCustomProperty("Trigger"):WaitForObject()
local AP_GREETING = script:GetCustomProperty("APGreeting")
local LOCAL_PLAYER = Game.GetLocalPlayer()

local AP = nil

function OnBeginOverlap(trigger, other)
    if AP == nil then
        if other:IsA("Player") and other == LOCAL_PLAYER then
            AP = World.SpawnAsset(AP_GREETING)
        end
    end
end

function OnPromptFinished()
    AP:Destroy()
    AP = nil
end

function OnEndOverlap(trigger, other)
    if AP then
        if other:IsA("Player") and other == LOCAL_PLAYER then
		    AP:Destroy()
            AP = nil
        end
	end
end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)
TRIGGER.endOverlapEvent:Connect(OnEndOverlap)
Events.Connect("PromptFinished", OnPromptFinished)