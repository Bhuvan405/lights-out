-- Internal custom properties
local ROTATION_ROOT = script:GetCustomProperty("RotationRoot"):WaitForObject()
local OPEN_SOUND = script:GetCustomProperty("OpenSound"):WaitForObject()
local CLOSE_SOUND = script:GetCustomProperty("CloseSound"):WaitForObject()

--local VOLUME = script.parent:GetCustomProperty("Volume")


--function OnCustomPropertyChanged(coreObject, propertyName)
	--VOLUME = script.parent:GetCustomProperty("Volume")
--end

--script.parent.networkedPropertyChangedEvent:Connect(OnCustomPropertyChanged)


-- Variable
local previousRotation = 0.0

local isOpening = false

-- float GetDoorRotation()
-- Gives you the current rotation of the door
function GetDoorRotation()
	return math.abs(ROTATION_ROOT:GetRotation().z / 90.0)
end


function Tick(deltaTime)
	local doorRotation = GetDoorRotation()

	local wasSnap = false
	--if math.abs(previousRotation - doorRotation) > 0.5 then
	--	wasSnap = true
	--end

	if isOpening then
		if doorRotation < previousRotation then
			isOpening = false
			if CLOSE_SOUND and not wasSnap then
				CLOSE_SOUND:Play()
				print("player close sound")
			end
		end
	else
		if doorRotation > previousRotation then
			isOpening = true
			print("player open sound")
			if OPEN_SOUND and not wasSnap then
				OPEN_SOUND:Play()
				print("player open sound")
			end
		end
	end

	previousRotation = doorRotation

end
