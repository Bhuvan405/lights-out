
local propGroup = script:GetCustomProperty("Group"):WaitForObject()
local propFantasyGauntletArm01 = script:GetCustomProperty("FantasyGauntletArm01"):WaitForObject()
local propCamera = script:GetCustomProperty("Camera"):WaitForObject()
local propSpace = script:GetCustomProperty("Space"):WaitForObject()
local propGoodbye = script:GetCustomProperty("Goodbye"):WaitForObject()
local propLetterText = script:GetCustomProperty("LetterText"):WaitForObject()

local children = propGroup:GetChildren()

local localOffsetLetter = Vector3.New(90,0,50)

local lettersToObjects = {}
for _, child in ipairs(children) do
    lettersToObjects[child.name] = child
end
lettersToObjects[' '] = propSpace


function ReadBoard(message)
   print ("Reading board")

    _G["cerberus.games.CameraInterpolation"].SetOverrideCamera(propCamera, 0.5)

    Task.Wait(1)

    local len = string.len(message)
    local lastLetter = nil
    -- loop each letter in our string
    for i = 1, len do
        local letter = string.sub(message,i,i)
        print(letter)

        local target = lettersToObjects[letter]

        if not target then
            -- Dont have the letter
            print("Couldnt find letter: " .. letter)
            Task.Wait(0.7)
        elseif target == lastLetter then
            Task.Wait(0.2)
            -- Same letter, do a little jiggle
            local targetPosition = target:GetWorldTransform():TransformPosition(localOffsetLetter + Vector3.New(0,0,50))
            targetPosition.z = propFantasyGauntletArm01:GetWorldPosition().z
            propFantasyGauntletArm01:MoveTo(targetPosition, 0.2)
            Task.Wait(0.2)

            targetPosition = target:GetWorldTransform():TransformPosition(localOffsetLetter)
            targetPosition.z = propFantasyGauntletArm01:GetWorldPosition().z
            propFantasyGauntletArm01:MoveTo(targetPosition, 0.2)
            Task.Wait(0.2)
            propLetterText.text = letter
            Task.Wait(0.3)
            propLetterText.text = ""
            Task.Wait(0.2)
        else
            -- Move to the letter
            local startPos = propFantasyGauntletArm01:GetWorldPosition()

            local targetPosition = target:GetWorldTransform():TransformPosition(localOffsetLetter)
            targetPosition.z = propFantasyGauntletArm01:GetWorldPosition().z

            local speed = 30 + math.random() * 30
            local duration = (startPos-targetPosition).size / speed
           
            -- turn the 3 lines below on to try a distance based approach so it moves at the same speed
            --local distance = (targetPosition - propFantasyGauntletArm01:GetWorldPosition()).size
            --local duration = distance / 50 
           -- duration = math.max(duration, 1)
            propFantasyGauntletArm01:MoveTo(targetPosition, duration)
            Task.Wait(duration)
            Task.Wait(0.2)
        end

        lastLetter = target
    end

    -- Finish on goodbye ;)
    local targetPosition = propGoodbye:GetWorldPosition()
    targetPosition.z = propFantasyGauntletArm01:GetWorldPosition().z
    propFantasyGauntletArm01:MoveTo(targetPosition, 0.5)
    Task.Wait(1)

    _G["cerberus.games.CameraInterpolation"].ClearOverrideCamera(0.5)

    Task.Wait(0.5)





end


