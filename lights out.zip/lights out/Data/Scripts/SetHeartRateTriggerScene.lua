local API = require(script:GetCustomProperty("API"))
local ROOT = script:GetCustomProperty("Root"):WaitForObject()
local BPM = script:GetCustomProperty("BPM")

local INTERMISSION = ROOT:GetCustomProperty("Intermission")
local DIALOG = ROOT:GetCustomProperty("Dialog")
local DIALOG_SUSTAIN = ROOT:GetCustomProperty("DialogSustain")
local TRIGGER = ROOT:GetCustomProperty("Trigger"):WaitForObject()

local startTime = nil

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        TRIGGER.isEnabled = false
        API.HeartBeatDriver.SetHeartRate(BPM)
    end
end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)