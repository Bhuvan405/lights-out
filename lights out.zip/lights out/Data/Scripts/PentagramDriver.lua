local FIRE_GROUP = script:GetCustomProperty("FireGroup"):WaitForObject()
local DAGGER = script:GetCustomProperty("Dagger"):WaitForObject()

function Initialize()
    for _, fireLine in ipairs(FIRE_GROUP:GetChildren()) do
        fireLine.isEnabled = false
    end
end

Initialize()

function PlayFireSequenceAsync()
    Task.Spawn(PlayFireSequence)
end

function PlayFireSequence()
    DAGGER.isEnabled = false
    
    for _, fireLine in ipairs(FIRE_GROUP:GetChildren()) do
        local startTime = time()

        local duration = fireLine:GetCustomProperty("Duration")
        local fireLineDuration = duration

        Task.Wait()

        fireLine.isEnabled = true
        fireLine:SetWorldScale(Vector3.New(0.001, 1, 1))
        repeat
            local r = (time() - startTime) / fireLineDuration
            if r > 1 then
                r = 1
            end
            fireLine:SetWorldScale(Vector3.New(r, 1, 1))

            print (r)
            Task.Wait()
        until r == 1
    end
end

