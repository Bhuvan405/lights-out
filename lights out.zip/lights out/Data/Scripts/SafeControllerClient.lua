local API = require(script:GetCustomProperty("API"))

local DEBUG_WORLDTEXT = script:GetCustomProperty("WorldText"):WaitForObject()
DEBUG_WORLDTEXT.text = ""

local TWISTKNOB = script:GetCustomProperty("TwistKnob"):WaitForObject()
local DOOR = script:GetCustomProperty("Door"):WaitForObject()
local CAMERA = script:GetCustomProperty("Camera"):WaitForObject()
local INTERACTIVE_POINT = script:GetCustomProperty("InteractivePoint"):WaitForObject()
local CHILD_TRIGGER = script:GetCustomProperty("ChildTrigger"):WaitForObject()
local BUTTON_CLICK_SOUND = script:GetCustomProperty("ButtonClickSound"):WaitForObject()

local OPEN_SAFE_SOUND = script:GetCustomProperty("OpenSafe"):WaitForObject()
local FAIL_SAFE_SOUND = script:GetCustomProperty("FailSafe"):WaitForObject()


CHILD_TRIGGER.isEnabled = false

local lastButtonFace = nil
local lastButtonNumber = nil
local lastHighlight = nil

local player = Game.GetLocalPlayer()

local mouseLocked = false

local codeInput = ""

local solutionCode = "1234"

local isInteracting = false

------------
local DEBUG_OPEN_SAFE = false -- dont forget to change this back!
--warn("Remember to turn off debug on the SafeControllerClient")

function OnGeneratedPin(pin)
    print("Set the pin!!!!")
    solutionCode = pin.firstDigit .. pin.secondDigit .. pin.thirdDigit .. pin.fourthDigit
end

Events.Connect("GeneratedPin", OnGeneratedPin)

local onBindingPressedBinding = nil

function OnPointInteraction(interactivePoint)
    if interactivePoint == INTERACTIVE_POINT then
        print ("On interaction")
        _G["cerberus.games.CursorClient"].ShowCursor()
        _G["cerberus.games.CameraInterpolation"].SetOverrideCamera(CAMERA, 0.5)
        isInteracting = true
        onBindingPressedBinding = player.bindingPressedEvent:Connect(OnBindingPressed)
        INTERACTIVE_POINT.context.pointInteractive = false
    end
end

function ExitSafe()
    codeInput = ""
    onBindingPressedBinding:Disconnect()
    _G["cerberus.games.CameraInterpolation"].ClearOverrideCamera(0.5)

    isInteracting = false
   _G["cerberus.games.CursorClient"].HideCursor()
    Task.Wait(0.5)

    INTERACTIVE_POINT.context.pointInteractive = true
end

Events.Connect("OnPointInteraction", OnPointInteraction)

function FlickerTheTorch()
    API.Torch.SilentClick(true)
    for i = 0, 10 do
    Task.Wait(0.01)
    API.Torch.On()
    Task.Wait(0.03)
    API.Torch.Off()
    end
    API.Torch.On()
    API.Torch.SilentClick(false)
end

warn("We need to check the 666 btw")

function OnBindingPressed(whichPlayer, binding)
    if whichPlayer == player then
        if (binding == "ability_primary") then
            if not mouseLocked then
                -- We left clicked!
                if lastHighlight then
                    local code = lastHighlight:GetCustomProperty("Input")

                    codeInput = codeInput .. code
                    DEBUG_WORLDTEXT.text = codeInput

                    lastButtonFace:SetColor(Color.New(1,0,0,1))
                    lastButtonNumber:SetColor(Color.New(1,1,0,1))
                    mouseLocked = true
                    Task.Wait(0.2)
                    mouseLocked = false

                    BUTTON_CLICK_SOUND:Play()

                    if (codeInput == "666") then
                        FlickerTheTorch() -- just an easter egg!
                    end

                    if string.len(codeInput) >= string.len(solutionCode) then
                        if (codeInput == solutionCode) or DEBUG_OPEN_SAFE then
                            TurnKnobSuccess()
                        else
                            TurnKnobFail()
                        end
                    end

                end
            end
        end
        if (binding == "ability_secondary") then
            ExitSafe()
        end
    end
end


function TurnKnobSuccess()
    OPEN_SAFE_SOUND:Play()

    mouseLocked = true
    TWISTKNOB:RotateTo(Rotation.New(0, -90, 0), 0.5, true)
    Task.Wait(1)
    DOOR:RotateTo(Rotation.New(0, 0, -90), 0.5, true)

    if Object.IsValid(CHILD_TRIGGER) then
        CHILD_TRIGGER.isEnabled = true
    end

    INTERACTIVE_POINT.context.isEnabled = false

    ExitSafe()
  
end


function TurnKnobFail()
    --
    Task.Spawn(
        function()
            local startTime = time()

            mouseLocked = true
            while true do
                t = (time() - startTime)*2
                local r = -math.sin(t * math.pi * 2) * (1-t) * 45
                if t > 1 then
                    break
                end
                TWISTKNOB:SetRotation(Rotation.New(0, r, 0))
                Task.Wait() -- wait a frame
            end

            mouseLocked = false
            codeInput = ""

        end
    )

    FAIL_SAFE_SOUND:Play()
    Task.Spawn(function() FAIL_SAFE_SOUND:FadeOut(0.5) end, 0.5)
end


function Tick()
    if mouseLocked then
        return
    end

    hitResult = UI.GetCursorHitResult()
 
    local buttonFace = nil
    local buttonNumber = nil

    if hitResult then

        local highlight = hitResult.other
        if highlight and string.sub(highlight.name,1, 6) == "Button" then
            local found = false

            buttonFace, found = highlight:GetCustomProperty("ButtonFace")
            if found then
                buttonFace = buttonFace:WaitForObject()
                buttonFace:SetColor(Color.New(0,0,0,1))
            end
            buttonNumber, found = highlight:GetCustomProperty("ButtonNumber")
            if found then
                buttonNumber = buttonNumber:WaitForObject()
                buttonNumber:SetColor(Color.New(1,1,1,1))
            end
        else
            highlight = nil
        end

        if lastHighlight ~= highlight then
            if lastButtonFace then
                lastButtonFace:SetColor(Color.New(1,1,1,1))
            end
            if lastButtonNumber then
                lastButtonNumber:SetColor(Color.New(0,0,0,1))
            end

            lastHighlight = highlight
            lastButtonFace = buttonFace
            lastButtonNumber = buttonNumber
        end
    end
end

function Initialize()
    math.randomseed(os.time())
    Events.Broadcast("GeneratedPin", {firstDigit = math.random(0,9), secondDigit = math.random(0,9), thirdDigit = math.random(0,9), fourthDigit = math.random(0,9)})
end

Initialize()