--[[
    SCENE STATE 8 INITIALIZATION
]]--


local API = require(script:GetCustomProperty("API"))

function EnterState()
    API.SkyLightDriver.Dark()

    -- Initialize with all lights off
    API.LightDriver.Off("All")

    API.Torch.On()

    API.DoorDriver.Open("Parents", 1)
end


return EnterState
