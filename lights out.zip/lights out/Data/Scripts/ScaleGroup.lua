children = script:GetChildren()

storedTransforms = {}

local groupScale = Vector3.ONE
local scaleHasChanged = false

function SetScale(scale)
    print ("set the scale to ", scale)
    groupScale = scale
    scaleHasChanged = true
end

function GetScale()
    return groupScale
end

for _, child in ipairs(children) do
    storedTransforms[child] = {
        position = child:GetPosition(),
        rotation = Quaternion.New(child:GetRotation()),
        scale = child:GetScale(),
    }
end

-- Todo, optimize
function Tick()
    if scaleHasChanged then
        for _, child in ipairs(children) do
            transform = storedTransforms[child]

            print("We are scaling")

            child:SetPosition(transform.position * groupScale)

            scaleX = (transform.rotation * (Vector3.FORWARD * transform.scale) ) * groupScale
            scaleY = (transform.rotation * (Vector3.RIGHT * transform.scale)) * groupScale
            scaleZ = (transform.rotation * (Vector3.UP * transform.scale)) * groupScale

            scaleX = -transform.rotation * scaleX
            scaleY = -transform.rotation * scaleY
            scaleZ = -transform.rotation * scaleZ

            child:SetScale( Vector3.New(scaleX.x, scaleY.y, scaleZ.z))
        end
        scaleHasChanged = false
    end
end